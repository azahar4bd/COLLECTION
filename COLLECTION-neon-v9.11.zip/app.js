/* =========================================================
   কালেকশন ম্যানেজার — কিস্তি রিপোর্ট (CSV)
   - CSV অটো-ডিটেক্ট (কোনো সিলেকশন/ম্যাপিং নেই)
   - ৩ টেবিল: বাকী কিস্তি · আদায় কিস্তি · আংশিক কিস্তি
       · InstallmentActual = 0                  → বাকী
       · InstallmentActual <  InstallmentAmount → আংশিক
       · InstallmentActual >= InstallmentAmount → আদায়
   - ফিল্টার: ষ্টাফ · সেন্টার কোড · মেম্বার কোড · তারিখ
   - Neon PostgreSQL-এ একমাত্র persistent data storage
   ========================================================= */
'use strict';

/* ---------------- Utils ---------------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (v) => String(v ?? '').replace(/[&<>\"']/g, (c) => (
  { '&': '&amp;', '<': '&lt;', '>': '&gt;', '\"': '&quot;', "'": '&#39;' }[c]
));
const norm = (v) => toEn(String(v ?? '')).trim().toLowerCase();
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

const BN_DIGIT = { '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4', '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9' };
const toEn = (s) => String(s ?? '').replace(/[০-৯]/g, (d) => BN_DIGIT[d]);
const num = (v) => {
  const n = parseFloat(toEn(String(v ?? '')).replace(/[৳,\sTk]/gi, ''));
  if (!Number.isFinite(n)) return 0;
  const rounded = Math.round(n * 100) / 100;
  return Number.isFinite(rounded) ? rounded : 0;
};
const fmt = (n) => Number(n || 0).toLocaleString('bn-BD', { maximumFractionDigits: 2 });
// UI-তে শুধু শেষ ৪টি মেম্বার সংখ্যা ও শেষ ৩টি সেন্টার সংখ্যা দেখাই; সংরক্ষিত মূল কোড অপরিবর্তিত থাকে।
const trailingDigits = (value) => toEn(String(value ?? '').trim()).match(/(\d+)$/)?.[1] || '';
const displayMemberCode = (value) => {
  const code = String(value ?? '').trim();
  const digits = trailingDigits(code);
  return digits.length >= 4 ? digits.slice(-4) : code;
};
const displayCenterCode = (value) => {
  const code = String(value ?? '').trim().split(',')[0].trim();
  const digits = trailingDigits(code);
  return digits.length >= 3 ? digits.slice(-3) : code;
};
// A→Z (ছোট থেকে বড়) সাজানো: কোডের সংখ্যা অংশ অনুযায়ী, নয়তো বাংলা অনুযায়ী।
const compareAZ = (a, b) => {
  const left = String(a ?? '').trim(), right = String(b ?? '').trim();
  const ld = toEn(left).match(/\d+/)?.[0], rd = toEn(right).match(/\d+/)?.[0];
  if (ld && rd) {
    const ln = Number(ld), rn = Number(rd);
    if (Number.isFinite(ln) && Number.isFinite(rn) && ln !== rn) return ln - rn;
  }
  return left.localeCompare(right, 'bn');
};
const sortAZ = (values) => [...values].sort(compareAZ);
// মেম্বার কোড তুলনা (UI-তে দেখানো শেষ ৪ সংখ্যা অনুযায়ী, সমান হলে মূল কোড অনুযায়ী)।
const compareMemberCodes = (a, b) => compareAZ(displayMemberCode(a), displayMemberCode(b)) || compareAZ(a, b);
// কিস্তি-সারিগুলো মেম্বার কোড অনুযায়ী ছোট থেকে বড় সাজানো।
function sortRowsAZ(rows) {
  const d = state.detect;
  return [...rows].sort((a, b) => {
    if (d.memberCode >= 0) {
      const cmp = compareMemberCodes(a[d.memberCode], b[d.memberCode]);
      if (cmp !== 0) return cmp;
    }
    if (d.memberName >= 0) {
      const cmp = compareAZ(a[d.memberName], b[d.memberName]);
      if (cmp !== 0) return cmp;
    }
    return 0;
  });
}

const toISODate = (v) => {
  const s = toEn(String(v ?? '')).trim();
  let m = s.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
  if (m) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
  m = s.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})/);
  if (m) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`; // dd/mm/yyyy (বাংলাদেশ)
  m = s.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{2})$/);
  if (m) return `20${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`; // dd/mm/yy
  return '';
};
/* সারির "তারিখ" কলামের মান → আইসো তারিখ (YYYY-MM-DD) */
function rowDateISO(row) {
  const d = state.detect;
  if (d.date < 0) return '';
  return toISODate(String(row[d.date] ?? '').trim());
}
/* তারিখ দেখানোর জন্য ছোট ফরম্যাট (dd-mm-yy) */
const shortDate = (value) => {
  const iso = toISODate(String(value ?? '').trim());
  if (!iso) return String(value ?? '').trim();
  const [y, m, day] = iso.split('-');
  return `${day}-${m}-${y.slice(2)}`;
};

let toastTimer = null;
function toast(msg, isErr = false) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.toggle('err', isErr);
  t.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add('hidden'), 3200);
}

/* ---------------- Settings: Neon is the only data store ---------------- */
const SET_KEY = 'collectionManager.settings.v1';
const APP_VER = 'v9.11';
// নতুন ভার্সন প্রকাশের পরে খোলা থাকা ট্যাবে পুরোনো app.js ক্যাশ থেকে চলতে না পারে —
// একবার রিফ্রেশ করে নতুন অ্যাসেট আনা হয় (প্রথমবার লোডে রিফ্রেশ হয় না)।
try {
  const buildKey = 'collectionManager.build.v1';
  const storedBuild = localStorage.getItem(buildKey);
  localStorage.setItem(buildKey, APP_VER);
  if (storedBuild && storedBuild !== APP_VER) location.reload();
} catch { /* localStorage না থাকলে চলবে */ }
const defaultSettings = () => ({ mode: 'neon', autoRefresh: true, refreshSec: 60 });
let previousSettings = {};
try {
  const parsedSettings = JSON.parse(localStorage.getItem(SET_KEY) || '{}');
  if (parsedSettings && typeof parsedSettings === 'object' && !Array.isArray(parsedSettings)) previousSettings = parsedSettings;
} catch { /* পুরোনো/ভাঙা সেটিংস হলে ডিফল্ট ব্যবহার */ }
let settings = { ...defaultSettings(), ...previousSettings, mode: 'neon' };
const saveSettings = () => localStorage.setItem(SET_KEY, JSON.stringify({
  mode: 'neon',
  autoRefresh: Boolean(settings.autoRefresh),
  refreshSec: Math.max(10, Math.min(3600, num(settings.refreshSec) || 60)),
}));
// আগের GitHub token/owner setting থেকে বাদ পড়ে; কোনো collection data মোছা হয় না।
saveSettings();
// Clear any access code retained by older versions; API is intentionally public.
try { sessionStorage.removeItem('collectionManager.neonAccessKey.v1'); } catch {}
const MEMBER_DB_KEY = 'collectionManager.memberDirectory.v1';
const TODAY_ROWS_KEY = 'collectionManager.todayCollections.v1';
const BALANCE_DB_KEY = 'collectionManager.balanceDirectory.v1';

/* ---------------- Neon API (database URL stays server-side) ---------------- */
const NEON_API = '/api/data';

async function neonResponseError(res) {
  let message = '';
  try { message = (await res.json()).error || ''; } catch { /* non-JSON response */ }
  if (res.status === 404) return new Error('Neon API endpoint পাওয়া যায়নি। সার্ভার ফাংশনসহ সাইটটি deploy হয়েছে কি না দেখুন।');
  if (res.status === 503) return new Error(message || 'Neon সার্ভার কনফিগার করা নেই—সার্ভার environment variables পরীক্ষা করুন।');
  return new Error(message || `Neon API ${res.status}`);
}

async function neonRead() {
  const res = await fetch(NEON_API, { cache: 'no-store' });
  if (!res.ok) throw await neonResponseError(res);
  return res.json();
}

async function neonWrite(document) {
  const res = await fetch(NEON_API, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(document),
  });
  if (!res.ok) throw await neonResponseError(res);
  return res.json();
}

/* ---------------- CSV parser ---------------- */
function detectDelimiter(line) {
  const candidates = [',', ';', '\t', '|'];
  let best = ',', bestCount = 0;
  for (const d of candidates) {
    const count = line.split(d).length - 1;
    if (count > bestCount) { bestCount = count; best = d; }
  }
  return best;
}

function parseCSV(text, delimiter) {
  text = text.replace(/^\uFEFF/, '');
  const rows = [];
  let row = [], cur = '', inQ = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQ) {
      if (c === '"') {
        if (text[i + 1] === '"') { cur += '"'; i++; }
        else inQ = false;
      } else cur += c;
    } else if (c === '"') inQ = true;
    else if (c === delimiter) { row.push(cur); cur = ''; }
    else if (c === '\n') { row.push(cur); if (row.some((v) => v.trim() !== '')) rows.push(row); row = []; cur = ''; }
    else if (c !== '\r') cur += c;
  }
  if (cur.length || row.length) { row.push(cur); if (row.some((v) => v.trim() !== '')) rows.push(row); }
  return rows;
}

/* ---------------- কলাম অটো-ডিটেক্ট (কোনো সিলেকশন নেই) ---------------- */
function normHeader(h) {
  return toEn(String(h ?? '')).toLowerCase().replace(/[^a-z0-9]+/g, '');
}

/* MIS/অফিস-রিপোর্টের অপ্রয়োজনীয় কলাম (SLNo, OfficeID, OfficeCode, OfficeName,
   ProductCode, ProductName, MainProductCode, MainItemName, EmployeeCode, SCBalance,
   Remarks, LoanSummaryID) ডিটেইলসে দেখানো হয় না — এগুলো লাগে না। */
const NOISE_COLUMN_PATTERNS = [
  /^sl/, /^sno$/, /^serial/, /office/, /product/, /^mainitem/,
  /employeecode/, /^scbalance/, /remark/, /loansummaryid/,
];
function isNoiseColumn(label) {
  const key = normHeader(label);
  if (!key) return false;
  return NOISE_COLUMN_PATTERNS.some((pattern) => pattern.test(key));
}

/* কিস্তি তালিকার সদস্য-বিস্তারিত কার্ড থেকে বাদ দেওয়া তথ্য —
   STATUS, MEMBER TYPE এবং INTCHARGE / NOOFFULLPAYMENT / NOOFPARTIALPAYMENT / NOOFNOTPAYMENT
   ব্যবহারকারীর নির্দেশে আর দেখানো হয় না (ডেটা মুছে যায় না, শুধু মডালে লুকানো)। */
const HIDDEN_DETAIL_KEYS = new Set([
  'status', 'membertype',
  'intcharge', 'nooffullpayment', 'noofpartialpayment', 'noofnotpayment',
]);
function stripHiddenDetails(entries) {
  const out = [];
  (Array.isArray(entries) ? entries : []).forEach((item) => {
    if (!item) return;
    // শিরোনামহীন কলাম ("তথ্য —") মডালে অগোছালো দেখায় — বাদ
    if (!item.divider && !item.hint && !String(item.label || '').trim()) return;
    if (!item.divider && !item.hint && HIDDEN_DETAIL_KEYS.has(normHeader(item.label))) return;
    out.push(item);
  });
  // সব কার্ড বাদ পড়ে কোনো হেডিং ফাঁকা হয়ে গেলে হেডিংটাও সরানো হয়
  return out.filter((item, index) => {
    if (!item.divider) return true;
    const next = out[index + 1];
    return Boolean(next && !next.divider);
  });
}

function detectColumns(headers) {
  const n = headers.map(normHeader);
  const pick = (test) => {
    let best = -1, bestScore = 0;
    n.forEach((h, i) => {
      const s = test(h) || 0;
      if (s > bestScore) { bestScore = s; best = i; }
    });
    return bestScore >= 40 ? best : -1;
  };
  const has = (h, ...ws) => ws.every((w) => h.includes(w));

  const actual = pick((h) =>
    h === 'installmentactual' || h === 'actualinstallment' ? 120 :
    (has(h, 'installment', 'actual') || has(h, 'instalment', 'actual')) && !h.includes('date') ? 100 :
    h.includes('actual') && !h.includes('date') ? 75 :
    has(h, 'paid', 'amount') || has(h, 'received', 'amount') || has(h, 'collection', 'amount') ? 60 : 0);

  const amount = pick((h) => {
    if (h === n[actual]) return 0;
    return (has(h, 'installment', 'amount') || has(h, 'instalment', 'amount')) && !h.includes('actual') ? 100 :
      (has(h, 'installmentamount') && !h.includes('actual')) ? 95 :
      has(h, 'due', 'amount') ? 70 :
      (h.includes('installment') || h.includes('instalment')) && !h.includes('actual') ? 65 :
      h === 'amount' || h === 'kisti' ? 55 :
      has(h, 'total', 'amount') ? 45 : 0;
  });

  const staff = pick((h) =>
    has(h, 'employee') ? 100 :
    has(h, 'staff') ? 95 :
    has(h, 'officer') ? 85 :
    has(h, 'collector') ? 80 :
    has(h, 'empcode') || has(h, 'empno') || has(h, 'empid') ? 75 : 0);

  const centerCode = pick((h) =>
    has(h, 'center', 'code') || has(h, 'centre', 'code') ? 100 :
    has(h, 'center', 'id') || has(h, 'centre', 'id') || has(h, 'center', 'no') || has(h, 'centre', 'no') ? 90 :
    h === 'center' || h === 'centre' || h === 'centercode' ? 60 : 0);

  const centerName = pick((h) => (has(h, 'center', 'name') || has(h, 'centre', 'name') ? 100 : 0));

  const memberCode = pick((h) =>
    has(h, 'member', 'code') || has(h, 'member', 'no') || has(h, 'member', 'id') || has(h, 'member', 'number') ? 100 :
    has(h, 'customer', 'code') || has(h, 'customer', 'no') || has(h, 'customer', 'id') ||
    has(h, 'client', 'code') || has(h, 'client', 'id') || has(h, 'borrower') ? 90 :
    has(h, 'memcode') || has(h, 'mcode') || has(h, 'custcode') || has(h, 'custid') ? 85 :
    has(h, 'loanaccount') || has(h, 'accountno') || has(h, 'accountnumber') || has(h, 'acno') ||
    has(h, 'loanid') || has(h, 'loanno') ? 80 :
    h === 'code' || h === 'id' ? 55 : 0);

  const memberName = pick((h) =>
    has(h, 'member', 'name') || has(h, 'customer', 'name') || has(h, 'client', 'name') || has(h, 'borrower', 'name') ? 100 :
    h.endsWith('name') && (h.includes('cust') || h.includes('mem') || h.includes('client')) ? 90 :
    h === 'name' || h === 'membername' ? 55 :
    (h.endsWith('name') && !h.includes('item') && !h.includes('product') &&
     !h.includes('center') && !h.includes('centre') && !h.includes('staff') && !h.includes('emp')) ? 45 : 0);

  const date = pick((h) =>
    // "Installment Date Actual" হলো আদায়ের তারিখ (বেশিরভাগ সারিতে খালি) — কিস্তির তারিখ নয়,
    // তাই "Installment Start Date"-এর চেয়ে কম গুরুত্ব পায়।
    has(h, 'installment', 'date') || has(h, 'instalment', 'date') ? (h.includes('actual') ? 90 : 105) :
    has(h, 'date', 'actual') || has(h, 'actual', 'date') ? 100 :
    has(h, 'due', 'date') ? 95 :
    has(h, 'paid', 'date') || has(h, 'payment', 'date') ? 90 :
    h.includes('date') ? 70 : 0);

  const staffName = pick((h) =>
    has(h, 'emp', 'name') || has(h, 'employee', 'name') || has(h, 'staff', 'name') ? 100 : 0);

  const mobileEnglish = pick((h) =>
    h.includes('mobile') ? 120 :
    h.includes('phone') ? 110 :
    h.includes('cell') ? 90 :
    h.includes('contact') ? 75 : 0);
  const mobileBangla = headers.findIndex((h) => /মোবাইল|মুঠোফোন|ফোন|যোগাযোগ/u.test(String(h ?? '')));
  const mobile = mobileEnglish >= 0 ? mobileEnglish : mobileBangla;

  return { actual, amount, staff, staffName, centerCode, centerName, memberCode, memberName, mobile, date };
}

const DETECT_LABELS = [
  ['actual', 'আদায় (InstallmentActual)'],
  ['amount', 'কিস্তি (InstallmentAmount)'],
  ['staff', 'ষ্টাফ কোড'],
  ['staffName', 'ষ্টাফ নাম'],
  ['centerCode', 'সেন্টার কোড'],
  ['memberCode', 'মেম্বার কোড'],
  ['memberName', 'মেম্বার নাম'],
  ['mobile', 'মোবাইল নম্বর'],
  ['date', 'তারিখ'],
  ['centerName', 'সেন্টার নাম'],
];

/* ---------------- App state ---------------- */
const state = {
  headers: [],          // CSV হেডার
  rows: [],             // [[cell, cell, ...], ...]
  detect: {},           // { actual, amount, staff, ... } → কলাম ইনডেক্স
  filters: { staff: '', center: '', member: '', searchBy: 'memberCode', date: '', followup: '', followupDate: '' },
  sectionView: 'all',
  editingToday: -1,
  todayRawMember: '',   // সদস্য ডিরেক্টরি থেকে পাওয়া মূল কোড (UI-তে শেষ ৪ সংখ্যা দেখায়)
  todayRawCenter: '',
  collections: [],      // আদায়ের পৃথক লেনদেন-তালিকা
  followups: [],        // সদস্যের প্রতিশ্রুতি ও পরবর্তী তারিখ
  activePage: 'installments',
  memberDB: [],
  memberDBHeaders: [],
  todayRows: [],
  history: [],          // হিসাব ক্লোজ করা এন্ট্রি (তারিখভিত্তিক স্থায়ী খাতা)
  balanceRows: [],
  balanceHeaders: [],
  csvData: null,        // আপলোডের সময়ের কাজচলা কপি
  lastSync: null,
};

// Use browser copies only as a one-time migration fallback; Neon is the shared source thereafter.
try { const m = JSON.parse(localStorage.getItem(MEMBER_DB_KEY) || '{}'); state.memberDBHeaders = Array.isArray(m.headers) ? m.headers : []; state.memberDB = Array.isArray(m.rows) ? m.rows : []; } catch {}
try { const t = JSON.parse(localStorage.getItem(TODAY_ROWS_KEY) || '[]'); state.todayRows = Array.isArray(t) ? t : []; } catch {}
try { const b = JSON.parse(localStorage.getItem(BALANCE_DB_KEY) || '{}'); state.balanceHeaders = Array.isArray(b.headers) ? b.headers : []; state.balanceRows = Array.isArray(b.rows) ? b.rows : []; } catch {}

/* ---------------- ক্লাসিফিকেশন ---------------- */
function rowStatus(r) {
  const d = state.detect;
  const actual = num(r[d.actual]);
  const amount = d.amount >= 0 ? num(r[d.amount]) : 0;
  if (actual <= 0) return 'due';
  if (d.amount >= 0 && amount > 0 && actual < amount) return 'partial';
  return 'paid';
}

const countByStatus = (rows) => {
  const out = { due: 0, paid: 0, partial: 0 };
  for (const r of rows) out[rowStatus(r)]++;
  return out;
};

function dailyDataSnapshot() {
  return {
    memberDBHeaders: state.memberDBHeaders,
    memberDB: state.memberDB,
    balanceHeaders: state.balanceHeaders,
    balanceRows: state.balanceRows,
    todayRows: state.todayRows,
  };
}
function applyDailyData(data) {
  state.memberDBHeaders = Array.isArray(data?.memberDBHeaders) ? data.memberDBHeaders : [];
  state.memberDB = Array.isArray(data?.memberDB) ? data.memberDB : [];
  state.balanceHeaders = Array.isArray(data?.balanceHeaders) ? data.balanceHeaders : [];
  state.balanceRows = Array.isArray(data?.balanceRows) ? data.balanceRows : [];
  state.todayRows = Array.isArray(data?.todayRows) ? data.todayRows : [];
}
function cacheDailyDataLocally() {
  try { localStorage.setItem(MEMBER_DB_KEY, JSON.stringify({ headers:state.memberDBHeaders, rows:state.memberDB })); } catch {}
  try { localStorage.setItem(BALANCE_DB_KEY, JSON.stringify({ headers:state.balanceHeaders, rows:state.balanceRows })); } catch {}
  try { localStorage.setItem(TODAY_ROWS_KEY, JSON.stringify(state.todayRows)); } catch {}
}

/* ---------------- Neon-এ শেয়ারড ডাটা load/save ---------------- */
const loadDB = async (quiet = false) => {
  const document = await neonRead();
  let headers = [], rows = [];
  if (document && Array.isArray(document.headers) && Array.isArray(document.rows)) {
    headers = document.headers;
    rows = document.rows.filter((r) => Array.isArray(r));
  }
  const collections = document && Array.isArray(document.collections) ? document.collections : [];
  const followups = document && Array.isArray(document.followups) ? document.followups : [];
  const history = document && Array.isArray(document.history) ? document.history : [];
  const cloudDaily = document?.dailyData;
  const validCloudDaily = cloudDaily && Array.isArray(cloudDaily.memberDBHeaders)
    && Array.isArray(cloudDaily.memberDB) && Array.isArray(cloudDaily.balanceHeaders)
    && Array.isArray(cloudDaily.balanceRows) && Array.isArray(cloudDaily.todayRows);
  const migrateLocalDaily = !validCloudDaily && Boolean(state.memberDB.length || state.balanceRows.length || state.todayRows.length);
  const oldDaily = JSON.stringify(dailyDataSnapshot());
  if (validCloudDaily) applyDailyData(cloudDaily);
  const changed = JSON.stringify(state.rows) !== JSON.stringify(rows)
    || JSON.stringify(state.collections) !== JSON.stringify(collections)
    || JSON.stringify(state.followups) !== JSON.stringify(followups)
    || JSON.stringify(state.history) !== JSON.stringify(history)
    || (validCloudDaily && oldDaily !== JSON.stringify(dailyDataSnapshot()));
  state.headers = headers;
  state.rows = rows;
  state.collections = collections;
  state.followups = followups;
  state.history = history;
  state.detect = detectColumns(headers);
  state.lastSync = new Date();
  if (migrateLocalDaily) {
    try { await persistRows(); toast('✅ এই ব্রাউজারের সদস্য/আজকের ডাটা Neon-এ শেয়ার করা হয়েছে'); }
    catch (error) { toast('⚠️ এই ব্রাউজারের ডাটা Neon-এ সিঙ্ক হয়নি: '+error.message,true); }
  }
  if (changed && quiet) { renderAll(); toast('🔄 ডাটা আপডেট হয়েছে'); }
};

const persistRows = async () => {
  const document = {
    updated_at: new Date().toISOString(),
    headers: state.headers,
    rows: state.rows,
    collections: state.collections,
    followups: state.followups,
    dailyData: dailyDataSnapshot(),
    history: state.history,
  };
  const result = await neonWrite(document);
  cacheDailyDataLocally();
  return result;
};

/* ---------------- ফিল্টার ---------------- */
function updateInstallmentSearchMode(clearValue = true) {
  const selector = $('#f-search-key'), input = $('#f-member');
  if (!selector || !input) return;
  const mode = selector.value;
  const dateMode = mode === 'promiseDate';
  // মেম্বার কোড ও সেন্টার কোড = শুধু সংখ্যা → মোবাইলে numeric কীবোর্ড; নাম = সাধারণ কীবোর্ড
  const numericMode = mode === 'memberCode' || mode === 'centerCode';
  if (clearValue) input.value = '';
  input.type = dateMode ? 'date' : 'search';
  if (dateMode) {
    input.removeAttribute('inputmode');
    input.removeAttribute('enterkeyhint');
  } else if (numericMode) {
    input.setAttribute('inputmode', 'numeric');
    input.setAttribute('enterkeyhint', 'done');
  } else {
    input.setAttribute('inputmode', 'text');
    input.setAttribute('enterkeyhint', 'search');
  }
  input.placeholder = dateMode
    ? ''
    : mode === 'memberCode' ? 'মেম্বার কোড লিখুন…'
    : mode === 'centerCode' ? 'সেন্টার কোড লিখুন…'
    : 'মেম্বার নাম লিখুন…';
  input.setAttribute('aria-label', dateMode ? 'প্রতিশ্রুতির তারিখ দিয়ে খুঁজুন' : numericMode ? 'কোড লিখে খুঁজুন' : 'সদস্যের নাম লিখে খুঁজুন');
  state.filters.searchBy = mode;
  state.filters.member = input.value.trim();
}
function filteredRows() {
  const f = state.filters, d = state.detect;
  const staffIdx = d.staffName >= 0 ? d.staffName : d.staff;
  return state.rows.filter((r) => {
    if (f.staff && staffIdx >= 0 && norm(r[staffIdx]) !== norm(f.staff)) return false;
    if (f.center && d.centerCode >= 0 && norm(r[d.centerCode]) !== norm(f.center)) return false;
    if (f.member) {
      if (f.searchBy === 'promiseDate') {
        const followup = getFollowup(r);
        if (!followup?.promise?.trim()) return false;
        const promised = String(followup.nextDate || '');
        const given = followupGivenDate(followup);
        if (promised !== f.member && given !== f.member) return false;
      } else {
        const q = norm(f.member);
        const idx = f.searchBy === 'centerCode'
          ? (d.centerCode >= 0 ? d.centerCode : d.centerName)
          : f.searchBy === 'memberName' ? d.memberName : d.memberCode;
        if (idx < 0) return false;
        const raw = norm(r[idx]);
        const shown = f.searchBy === 'centerCode' ? norm(displayCenterCode(r[idx])) : f.searchBy === 'memberCode' ? norm(displayMemberCode(r[idx])) : raw;
        if (!raw.includes(q) && !shown.includes(q)) return false;
      }
    }
    if (f.date && d.date >= 0) {
      const cell = String(r[d.date] ?? '');
      if (toISODate(cell) !== f.date && cell.trim() !== f.date) return false;
    }
    if (f.followup || f.followupDate) {
      const followup = getFollowup(r);
      if (!followup) return false;
      if (f.followup && !norm(followup.promise).includes(norm(f.followup))) return false;
      if (f.followupDate && String(followup.nextDate || '') !== f.followupDate) return false;
    }
    return true;
  });
}

/* ---------------- রেন্ডার ---------------- */
function tableColumns() {
  const d = state.detect, cols = [], used = new Set();
  const add = (idx, label) => {
    if (idx >= 0 && !used.has(idx)) { cols.push({ idx, label }); used.add(idx); }
  };
  add(d.memberCode, 'মেম্বার কোড');
  add(d.memberName, 'মেম্বার নাম');
  add(d.centerCode, 'সেন্টার কোড');
  add(d.centerName, 'সেন্টার নাম');
  if (d.staffName >= 0) add(d.staffName, 'ষ্টাফ নাম');
  else add(d.staff, 'ষ্টাফ');
  add(d.date, 'তারিখ');
  add(d.amount, 'কিস্তি (৳)');
  add(d.actual, 'আদায় (৳)');
  cols.push({ idx: -1, label: 'বাকী (৳)', virtual: 'bal' });
  return cols; // শুধু দরকারি কলাম — বাকি অতিরিক্ত কলাম দেখানো হয় না
}

const RENDER_CAP = 500;

function cellHTML(r, c) {
  const d = state.detect;
  if (c.virtual === 'bal') {
    const amt = d.amount >= 0 ? num(r[d.amount]) : 0;
    const act = num(r[d.actual]);
    return `<td class="amt">${fmt(Math.max(0, amt - act))}</td>`;
  }
  const v = r[c.idx] ?? '';
  if (c.idx === d.memberCode) return `<td>${esc(displayMemberCode(v))}</td>`;
  if (c.idx === d.centerCode) return `<td>${esc(displayCenterCode(v))}</td>`;
  if (c.idx === d.date) return `<td class="date-cell">${esc(shortDate(v))}</td>`;
  if (c.idx === d.amount || c.idx === d.actual) return `<td class="amt">${fmt(num(v))}</td>`;
  return `<td>${esc(v)}</td>`;
}

function followupKey(row) {
  const d=state.detect;
  const code=d.memberCode>=0?String(row[d.memberCode]??'').trim():'';
  if(code) return `code:${normalizedDigits(code).replace(/^0+/,'')||norm(code)}`;
  const name=d.memberName>=0?norm(row[d.memberName]):'';
  const center=d.centerCode>=0?norm(row[d.centerCode]):'';
  return `member:${center}:${name}`;
}
function getFollowup(row) { const key=followupKey(row); return state.followups.find(item=>item.key===key) || null; }
function followupGivenDate(item) {
  if (item?.givenDate) return String(item.givenDate).slice(0,10);
  if (!item?.updatedAt) return '';
  const date = new Date(item.updatedAt);
  if (Number.isNaN(date.getTime())) return String(item.updatedAt).slice(0,10);
  const pad = (value) => String(value).padStart(2,'0');
  return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}`;
}
let followupRowIndex=null;
function openFollowupModal(rowIndex) {
  const row=state.rows[rowIndex]; if(!row) return;
  followupRowIndex=rowIndex;
  const d=state.detect; const code=d.memberCode>=0?displayMemberCode(row[d.memberCode]):''; const name=d.memberName>=0?String(row[d.memberName]||''):'';
  $('#followup-member').textContent=[code,name].filter(Boolean).join(' · ')||`সারি ${fmt(rowIndex+1)}`;
  const existing=getFollowup(row);
  $('#followup-promise').value=existing?.promise||'';
  $('#followup-date').value=existing?.nextDate||'';
  $('#followup-error').classList.add('hidden');
  $('#followup-modal').classList.remove('hidden'); updateModalScrollLock();
}
async function saveFollowup() {
  const row=state.rows[followupRowIndex]; if(!row) return;
  const promise=$('#followup-promise').value.trim(); const nextDate=$('#followup-date').value;
  const key=followupKey(row); const old=[...state.followups];
  state.followups=state.followups.filter(item=>item.key!==key);
  if(promise||nextDate){
    const d=state.detect;
    state.followups.push({key,memberCode:d.memberCode>=0?String(row[d.memberCode]??''):'',memberName:d.memberName>=0?String(row[d.memberName]??''):'',promise,nextDate,givenDate:localDateInputValue(),updatedAt:new Date().toISOString()});
  }
  const button=$('#btn-save-followup'); button.disabled=true; button.textContent='⏳ সেভ হচ্ছে...';
  try {
    await persistRows();
    state.lastSync=new Date(); $('#followup-modal').classList.add('hidden'); updateModalScrollLock(); followupRowIndex=null;
    renderAll(); toast(promise||nextDate?'✅ প্রতিশ্রুতি ও পরবর্তী তারিখ Neon-এ সেভ হয়েছে':'✅ প্রতিশ্রুতি/তারিখ মুছে দেওয়া হয়েছে');
  } catch(e) {
    state.followups=old; $('#followup-error').textContent='⚠️ সেভ করা যায়নি: '+e.message; $('#followup-error').classList.remove('hidden'); renderAll();
  } finally { button.disabled=false; button.textContent='💾 সেভ করুন'; }
}

function renderSection(key, rows) {
  const cols = tableColumns();
  const d = state.detect;
  // কিস্তি তালিকা থেকে সরাসরি আদায় নেওয়া বন্ধ — আদায় হয় Today All Collection পেজ থেকে।
  const canCollect = false;
  const showFollowup = key !== 'paid';
  const extraCols = (canCollect ? 1 : 0) + (showFollowup ? 1 : 0);
  const thead = $(`#table-${key} thead`);
  const tbody = $(`#tbl-${key}`);
  if (!thead || !tbody) return;

  thead.innerHTML = `<tr>${cols.map((c) => {
    const isAmt = c.virtual === 'bal' || c.idx === d.amount || c.idx === d.actual;
    return `<th class="${isAmt ? 'amt' : ''}">${esc(c.label)}</th>`;
  }).join('')}${canCollect ? '<th class="action-heading">আদায়</th>' : ''}${showFollowup ? '<th>প্রতিশ্রুতি / পরবর্তী তারিখ</th>' : ''}</tr>`;

  const shown = rows.slice(0, RENDER_CAP);
  tbody.innerHTML = shown.map((r) => {
    const cells = cols.map((c) => cellHTML(r, c)).join('');
    const rowIndex = state.rows.indexOf(r);
    const followup=getFollowup(r);
    // এই ঘরটি শুধু ইউজার নিজে হাতে লেখা প্রতিশ্রুতি / পরবর্তী তারিখ দেখায় — নিজে থেকে কোনো তারিখ বসানো হয় না
    const followupCell=showFollowup?`<td class="followup-cell">${followup?`<span class="followup-preview">${followup.promise?esc(followup.promise):''}${followup.nextDate?`<small>📅 ${esc(shortDate(followup.nextDate))}</small>`:''}</span>`:'<span class="followup-empty">—</span>'}<button class="followup-btn" type="button" data-followup-index="${rowIndex}" title="প্রতিশ্রুতি / পরবর্তী তারিখ লিখুন">📝 ${followup?'সম্পাদনা':'লিখুন'}</button></td>`:'';
    return `<tr class="clickable-row" data-row-index="${rowIndex}">${cells}${followupCell}</tr>`;
  }).join('')
    + (rows.length > RENDER_CAP
      ? `<tr><td colspan="${cols.length + extraCols}" style="text-align:center;color:var(--muted)">… আরও ${fmt(rows.length - RENDER_CAP)} সারি — ফিল্টার দিয়ে খুঁজুন</td></tr>`
      : '');

  $(`#count-${key}`).textContent = fmt(rows.length);
  $(`#empty-${key}`).classList.toggle('hidden', rows.length > 0);

  let sumAmt = 0, sumAct = 0, sumBal = 0;
  for (const r of rows) {
    const amt = d.amount >= 0 ? num(r[d.amount]) : 0;
    const act = num(r[d.actual]);
    sumAmt += amt; sumAct += act; sumBal += Math.max(0, amt - act);
  }
  $(`#sum-${key}`).innerHTML = `
    <div class="totals">
      <div class="total-box highlight"><span>মোট সংখ্যা</span><strong>${fmt(rows.length)}</strong></div>
      <div class="total-box"><span>মোট কিস্তি</span><strong>৳ ${fmt(sumAmt)}</strong></div>
      <div class="total-box"><span>মোট আদায়</span><strong>৳ ${fmt(sumAct)}</strong></div>
      <div class="total-box"><span>মোট বাকী</span><strong>৳ ${fmt(sumBal)}</strong></div>
    </div>`;
}


const roundMoney = (value) => {
  const number = Number(value);
  if (!Number.isFinite(number)) return 0;
  const rounded = Math.round(number * 100) / 100;
  return Number.isFinite(rounded) ? rounded : 0;
};
const localDateInputValue = () => {
  const now = new Date();
  return new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
};



function safeTelephone(value) {
  let digits = toEn(String(value ?? '')).trim().replace(/(?!^\+)[^0-9]/g, '');
  if (/^[1-9]\d{9}$/.test(digits)) digits = '0' + digits;
  return digits;
}

function formatMemberDetails(entries, codeColumn = -1) {
  return (entries || [])
    .map((item, index) => ({ item, index }))
    .filter(({ item }) => !isNoiseColumn(item?.label))   // SLNo/OfficeID/ProductCode… অপ্রয়োজনীয় কলাম বাদ
    .flatMap(({ item, index }) => {
      const heading = normHeader(item.label || '');
      const looksLikeCode = heading.includes('member') && (heading.includes('no') || heading.includes('code') || heading.includes('id'));
      const isCenterCol = heading.includes('center') || heading.includes('centre') || heading.includes('samity')
        || String(item.label || '').toLowerCase().includes('সেন্টার');
      // "0001, GOBRA BAZAR" থেকে কোড ও নাম আলাদা দেখানো হয়।
      if (isCenterCol) {
        const parts = String(item.value ?? '').split(',').map((part) => part.trim());
        const codePart = parts.shift() || '';
        const namePart = parts.join(', ');
        const isCodeCol = heading.includes('code') || heading.includes('no') || heading.includes('id');
        if (isCodeCol) {
          const out = [{ ...item, value: displayCenterCode(codePart) }];
          if (namePart) out.push({ label: 'সেন্টারের নাম', value: namePart });
          return out;
        }
        // আলাদা "Center Name" কলামে কোড-নাম একসাথে থাকলে শুধু নামটুকু দেখানো হয়।
        if (namePart) return [{ ...item, value: namePart }];
        return [{ ...item, value: displayCenterCode(codePart) }];
      }
      const value = index === codeColumn || looksLikeCode ? displayMemberCode(item.value) : item.value;
      return [{ ...item, value }];
    });
}

/* ডিটেইলসে গুরুত্বপূর্ণ তথ্য (কোড, নাম, সেন্টার, পিতা/স্বামী/অভিভাবক, মোবাইল, কিস্তি) আগে,
   MIS/লোন-টেকনিক্যাল তথ্য পরে আলাদা হেডিং-এর নিচে দেখানো হয়। */
function detailPriority(label) {
  const n = normHeader(label || '');
  const raw = String(label || '').toLowerCase();
  // Today পেজের 'আজকের লোন/সঞ্চয়/DPS/মোট' ও সর্বশেষ স্থিতি — সবচেয়ে গুরুত্বপূর্ণ, তাই একদম উপরে
  if (raw.startsWith('আজকের') || raw.includes('স্থিতি')) return 0;
  if (n.includes('father') || n.includes('husband') || n.includes('careof') || n.includes('guardian')
    || raw.includes('পিতা') || raw.includes('স্বামী') || raw.includes('অভিভাবক')) return 3;
  if (n.includes('member') && (n.includes('no') || n.includes('code') || n.includes('id'))) return 0;
  if (n.includes('membername') || n === 'name' || raw.includes('সদস্যের নাম')) return 1;
  const isCenter = n.includes('center') || n.includes('centre') || n.includes('samity') || raw.includes('সেন্টার');
  if (isCenter) return (n.includes('code') || n.includes('no') || n.includes('id')) ? 2 : 3.5;
  if (n.includes('contact') || n.includes('mobile') || n.includes('phone') || raw.includes('মোবাইল')) return 4;
  if (n.includes('staff') || n.includes('officer') || n.includes('collector')
    || (n.includes('emp') && n.includes('name')) || (n.includes('employee') && n.includes('name'))) return 4.5;
  if (n.includes('installment') || n.includes('instalment') || n.includes('kisti') || raw.includes('কিস্তি')) return 5;
  if (n.includes('date') || raw.includes('তারিখ')) return 6;
  return 9;
}
function prioritizeDetails(entries) {
  const list = (entries || []).filter((item) => item && !item.divider);
  const hints = list.filter((item) => item.hint);
  const plain = list.filter((item) => !item.hint);
  if (plain.length < 2) return [...plain, ...hints];
  const sorted = plain
    .map((item, index) => ({ item, index, score: detailPriority(item.label) }))
    .sort((a, b) => (a.score - b.score) || (a.index - b.index))
    .map((entry) => entry.item);
  const mainCount = sorted.filter((item) => detailPriority(item.label) <= 6).length;
  if (!mainCount || mainCount === sorted.length) return [...sorted, ...hints];
  return [
    ...sorted.slice(0, mainCount),
    { divider: true, label: '📋 অন্যান্য তথ্য (লোন / MIS)' },
    ...sorted.slice(mainCount),
    ...hints,
  ];
}

function openMemberDetails(entries, mobile = '', title = 'সদস্যের তথ্য') {
  const phone = String(mobile ?? '').trim();
  const tel = safeTelephone(phone);
  $('#member-modal-title').textContent = title || 'সদস্যের তথ্য';
  $('#member-call-action').innerHTML = tel
    ? `<a class="call-button" href="tel:${esc(tel)}">📞 কল করুন <span>${esc(tel)}</span></a>`
    : '<span class="no-phone">📵 মোবাইল নম্বর পাওয়া যায়নি</span>';
  const list = Array.isArray(entries) ? entries : [];
  const dividerAt = list.findIndex((item) => item && item.divider);
  const head = dividerAt >= 0 ? list.slice(0, dividerAt) : list;
  const tail = dividerAt >= 0 ? list.slice(dividerAt) : [];
  const organized = prioritizeDetails(head);
  // সদস্য ডাটাবেজের অংশ (পিতা/স্বামী/অভিভাবক) MIS-ব্লকের আগে বসে, যাতে গুরুত্বপূর্ণ তথ্য উপরেই থাকে।
  const misAt = organized.findIndex((item) => item && item.divider);
  const finalOrder = misAt >= 0
    ? [...organized.slice(0, misAt), ...tail, ...organized.slice(misAt)]
    : [...organized, ...tail];
  $('#member-detail-grid').innerHTML = finalOrder.map((item) => {
    if (!item) return '';
    if (item.divider) return `<div class="detail-divider">${esc(item.label || '')}</div>`;
    if (item.hint) return `<div class="detail-hint">${esc(item.label || '')}</div>`;
    if (!String(item.label || '').trim()) return '';   // শিরোনামহীন কলাম বাদ
    return `<div class="detail-item"><span>${esc(item.label)}</span><strong>${esc(item.value || '—')}</strong></div>`;
  }).join('') || '<div class="empty">কোনো সদস্য-তথ্য পাওয়া যায়নি।</div>';
  $('#member-details-modal').classList.remove('hidden');
  updateModalScrollLock();
}

/* কোড না মিললে নাম ও সেন্টার দিয়ে সদস্য ডাটাবেজের সারি খোঁজা (শুধু একটাই মিললে)। */
function findDirectoryByName(name, centerHint = '') {
  const ni = memberCol(state.memberDBHeaders, 'name');
  if (ni < 0 || !name) return null;
  const target = norm(name);
  if (!target) return null;
  let matches = state.memberDB.filter((row) => norm(row[ni]) === target);
  if (matches.length > 1 && centerHint) {
    const ci = memberCol(state.memberDBHeaders, 'center');
    const cd = normalizedDigits(String(centerHint).split(',')[0]).replace(/^0+/, '');
    const byCenter = matches.filter((row) => {
      const c = normalizedDigits(String(row[ci] || '').split(',')[0]).replace(/^0+/, '');
      return c === cd || (cd.length >= 3 && c.endsWith(cd));
    });
    if (byCenter.length) matches = byCenter;
  }
  return matches.length === 1 ? matches[0] : null;
}

/* সদস্য ডাটাবেজ (Today All Collection) থেকে ডিটেইলসে অতিরিক্ত তথ্য যোগ করা —
   পিতা/স্বামী/অভিভাবকসহ অন্যান্য কলাম, কিস্তি তালিকার সারিতে না থাকলেও দেখানো হয়। */
function detailKey(label) {
  const text = String(label ?? '').trim();
  return normHeader(text) || text.toLowerCase();
}
function mergeDirectoryDetails(entries, code, centerHint = '', nameHint = '') {
  const base = (Array.isArray(entries) ? entries : []).filter(Boolean).map((item) => ({ ...item }));
  const row = resolveDirectoryRow(code, centerHint) || findDirectoryByName(nameHint, centerHint);
  if (!row) {
    const hint = { hint: true, label: 'ℹ️ এই সদস্যের পিতা/স্বামী/অভিভাবকের তথ্য সদস্য ডাটাবেজে পাওয়া যায়নি — সদস্য CSV আপডেট করলে এখানে দেখা যাবে।' };
    return { entries: [...base, hint], mobile: '', matched: false };
  }
  const headers = state.memberDBHeaders || [];
  const codeIndex = memberCol(headers, 'code');
  const nameIndex = memberCol(headers, 'name');
  const mobileIndex = memberCol(headers, 'mobile');
  const centerIndex = memberCol(headers, 'center');
  const guardianIndex = memberCol(headers, 'guardian');
  const baseKeys = new Set(base.map((item) => detailKey(item.label)));
  const baseHas = (test) => base.some((item) => test(normHeader(item.label || ''), String(item.label || '').toLowerCase()));
  const hasGuardian = baseHas((n, raw) => n.includes('father') || n.includes('husband') || n.includes('careof') || n.includes('guardian')
    || raw.includes('পিতা') || raw.includes('স্বামী') || raw.includes('অভিভাবক') || raw.includes('care of'));
  const hasCenter = baseHas((n, raw) => n.includes('center') || n.includes('centre') || n.includes('samity')
    || raw.includes('সেন্টার') || raw.includes('কেন্দ্র'));
  const added = [];
  const seen = new Set();
  const push = (label, value) => {
    const key = detailKey(label);
    const text = String(value ?? '').trim();
    if (!label || !text || seen.has(key) || baseKeys.has(key)) return;
    seen.add(key);
    added.push({ label, value: text });
  };
  headers.forEach((header, index) => {
    const label = String(header || '').replace(/\s+/g, ' ').trim();
    const value = String(row[index] ?? '').trim();
    if (!label || !value) return;
    if (index === codeIndex || index === nameIndex || index === mobileIndex) return;
    if (index === centerIndex) return;
    if (index === guardianIndex) { if (!hasGuardian) push(label, value); return; }
    if (/^sl\.?\s*no\.?$/i.test(label) || normHeader(label) === 'slno') return;
    push(label, value);
  });
  if (!hasCenter && centerIndex >= 0) {
    const parts = String(row[centerIndex] || '').split(',').map((part) => part.trim());
    const centerCode = parts.shift() || '';
    const centerName = parts.join(', ');
    if (centerCode) push('সেন্টার কোড', displayCenterCode(centerCode));
    if (centerName) push('সেন্টারের নাম', centerName);
  }
  const mobile = mobileIndex >= 0 ? String(row[mobileIndex] ?? '').trim() : '';
  if (!added.length) return { entries: base, mobile, matched: true };
  return {
    entries: [...base, { divider: true, label: '🗃️ সদস্য ডাটাবেজ (Today All Collection) থেকে' }, ...formatMemberDetails(added, -1)],
    mobile,
    matched: true,
  };
}

function openMemberDetailsFromRow(rowIndex) {
  const row = state.rows[rowIndex];
  if (!row) return;
  const d = state.detect;
  const entries = formatMemberDetails(state.headers.map((header, i) => ({ label: String(header), value: String(row[i] ?? '') })), d.memberCode);
  const rawCode = d.memberCode >= 0 ? String(row[d.memberCode] ?? '') : '';
  const center = d.centerCode >= 0 ? String(row[d.centerCode] ?? '') : '';
  const memberName = d.memberName >= 0 ? String(row[d.memberName] ?? '').trim() : '';
  const merged = mergeDirectoryDetails(entries, rawCode, center, memberName);
  const mobile = (d.mobile >= 0 ? String(row[d.mobile] ?? '').trim() : '') || merged.mobile;
  const code = d.memberCode >= 0 ? displayMemberCode(row[d.memberCode]) : '';
  const name = memberName;
  openMemberDetails(stripHiddenDetails(merged.entries), mobile, [code, name].filter(Boolean).join(' · ') || 'সদস্যের তথ্য');
}


function installmentRowKey(row) {
  const d=state.detect;
  const signature=JSON.stringify(row.map((value,index)=>index===d.actual?'':String(value??'')));
  let hash=2166136261;
  for(let i=0;i<signature.length;i++){hash^=signature.charCodeAt(i);hash=Math.imul(hash,16777619);}
  const base=(hash>>>0).toString(36);
  const rowIndex=state.rows.indexOf(row);
  const duplicateRank=rowIndex<0?0:state.rows.slice(0,rowIndex).filter(candidate=>JSON.stringify(candidate.map((value,index)=>index===d.actual?'':String(value??'')))===signature).length;
  return `${base}:${duplicateRank}`;
}


function renderTables() {
  const rows = sortRowsAZ(filteredRows());
  const groups = { due: [], paid: [], partial: [] };
  const today = localDateInputValue();
  for (const r of rows) groups[rowStatus(r)].push(r);
  // "আজ প্রতিশ্রুতি" = যেসব সদস্যের **প্রতিশ্রুতি / পরবর্তী তারিখ (ইউজার নিজে হাতে যা লিখেছেন) = আজ**।
  // শর্ত = প্রতিশ্রুতির তারিখ (কিস্তির তারিখ বা আদায়ের অবস্থা নয়) — যে সদস্য আজ আসার ওয়াদা দিয়েছেন, তিনিই এই তালিকায়।
  // "আজ আদায়যোগ্য" = আজ যে কিস্তি পড়েছে (কিস্তির তারিখ = আজ) অথচ টাকা এখনো পুরো আসেনি (বাকী + আংশিক)।
  const payable = rows.filter((row) => {
    const st = rowStatus(row);
    return (st === 'due' || st === 'partial') && rowDateISO(row) === today;
  });
  const todayPromises = rows.filter((row) => {
    const followup = getFollowup(row);
    return !!followup && String(followup.nextDate || '').slice(0, 10) === today;
  });

  renderSection('today-promise', todayPromises);   // আজ প্রতিশ্রুতি (সবার উপরে)
  renderSection('payable', payable);               // আজ আদায়যোগ্য (আজ প্রতিশ্রুতি ও বাকী কিস্তির মাঝে)
  renderSection('due', groups.due);
  renderSection('paid', groups.paid);
  renderSection('partial', groups.partial);

  const todayLabel = shortDate(today);
  const dateBadge = $('#today-promise-date');
  if (dateBadge) dateBadge.textContent = `(${todayLabel})`;
  const emptyPromise = $('#empty-today-promise');
  if (emptyPromise) emptyPromise.textContent = `আজ (${todayLabel}) তারিখের জন্য কোনো প্রতিশ্রুতি লেখা নেই — কিস্তি তালিকার 📝 লিখুন থেকে লিখুন।`;

  $('#chip-due strong').textContent = fmt(groups.due.length);
  $('#chip-paid strong').textContent = fmt(groups.paid.length);
  $('#chip-partial strong').textContent = fmt(groups.partial.length);

  const hasData = state.rows.length > 0;
  $('#no-data').classList.toggle('hidden', hasData);
  $$('[data-sec]').forEach((el) => el.classList.toggle('hidden', !hasData));
  $('#summary-chips').classList.toggle('hidden', !hasData);
  applySectionView();
}

// কোন তালিকা দেখাবেন (সব / আজ প্রতিশ্রুতি / বাকী / আদায় / আংশিক)
const SECTION_KEYS = ['today-promise', 'payable', 'due', 'paid', 'partial'];

/* সব তালিকা ডিফল্টে বন্ধ (collapsed) — মাথায় চাপ দিলে খোলে */
function collapseAllSections() {
  SECTION_KEYS.forEach((key) => {
    const el = $('#sec-' + key);
    if (el) el.classList.add('collapsed');
  });
}
function expandSection(key) {
  const el = $('#sec-' + key);
  if (el) el.classList.remove('collapsed');
}

function applySectionView() {
  const view = state.sectionView || 'all';
  const hasData = state.rows.length > 0;
  SECTION_KEYS.forEach((key) => {
    const el = $('#sec-' + key);
    if (!el) return;
    const show = hasData && (view === 'all' || view === key);
    el.classList.toggle('hidden', !show);
    /* একক তালিকা বাছলে সেটা নিজে থেকেই খুলে যায় */
    if (show && view !== 'all') el.classList.remove('collapsed');
  });
}





const memberCol = (headers, kind) => {
  const hs = headers.map((h) => normHeader(h));
  const tests = {
    code: (h) => (h.includes('member') && (h.includes('no') || h.includes('code') || h.includes('number'))) || h === 'memno',
    center: (h) => h.includes('center') && (h.includes('code') || h.includes('name')),
    name: (h) => h.includes('membername') || h === 'name',
    mobile: (h) => h.includes('contactnumber') || h.includes('mobile') || h.includes('phone'),
    guardian: (h) => h.includes('father') || h.includes('husband') || h.includes('careof') || h.includes('guardian'),
    status: (h) => h.includes('status'),
  };
  return hs.findIndex(tests[kind] || (() => false));
};
function memberHeadersRow(rows) {
  return rows.findIndex((r) => {
    const n = r.map(normHeader);
    return n.some((x) => x.includes('member') && (x.includes('no') || x.includes('code')))
      && n.some((x) => x.includes('contact') || x.includes('mobile'));
  });
}
function findDirectoryMember(code, centerHint = '') {
  const idx = memberCol(state.memberDBHeaders, 'code');
  if (idx < 0 || !code) return null;
  const digits = normalizedDigits(code);
  const key = digits.replace(/^0+/, '');
  const exact = state.memberDB.find((row) => normalizedDigits(row[idx]).replace(/^0+/, '') === key);
  if (exact) return exact;
  // Balance CSV-র ছোট Member ID-ও full directory Member No-র শেষাংশ হতে পারে।
  if (digits.length < 3) return null;
  let candidates = state.memberDB.filter((row) => normalizedDigits(row[idx]).endsWith(digits));
  const typedCenter = normalizedDigits(centerHint || state.todayRawCenter || $('#today-center-code')?.value || '');
  if (typedCenter && candidates.length > 1) {
    const centerIndex = memberCol(state.memberDBHeaders, 'center');
    const byCenter = candidates.filter((row) => {
      const center = normalizedDigits(String(row[centerIndex] || '').split(',')[0]);
      return center === typedCenter || (typedCenter.length >= 3 && center.endsWith(typedCenter));
    });
    if (byCenter.length) candidates = byCenter;
  }
  return candidates.length === 1 ? candidates[0] : null;
}

// UI-তে দেখানো শেষ ৪ সংখ্যা দিয়ে সদস্য খোঁজা হলে মূল কোডসহ ডিরেক্টরি সারি বের করা।
function resolveDirectoryRow(typed, centerHint = '') {
  const idx = memberCol(state.memberDBHeaders, 'code');
  if (idx < 0 || !typed) return null;
  const digits = normalizedDigits(typed);
  const pickByCenter = (matches) => {
    if (matches.length === 1) return matches[0];
    if (matches.length > 1) {
      const typedCenter = normalizedDigits(centerHint || state.todayRawCenter || $('#today-center-code')?.value || '');
      if (typedCenter) {
        const centerIndex = memberCol(state.memberDBHeaders, 'center');
        const byCenter = matches.filter((row) => {
          const center = normalizedDigits(String(row[centerIndex] || '').split(',')[0]);
          return center === typedCenter || (typedCenter.length >= 3 && center.endsWith(typedCenter));
        });
        if (byCenter.length === 1) return byCenter[0];
      }
    }
    return null;
  };
  // ছোট (৪ সংখ্যা) কোড লিখলে প্রথমে UI-তে দেখানো শেষ ৪ সংখ্যার সাথে মেলানো।
  if (digits.length <= 4) {
    const short = toEn(String(typed)).trim();
    const matches = state.memberDB.filter((row) => displayMemberCode(row[idx]) === short);
    const hit = pickByCenter(matches);
    if (hit) return hit;
  }
  return findDirectoryMember(typed, centerHint);
}
function dailyAccountKey(item) {
  const directoryRow = resolveDirectoryRow(item.memberCode, item.centerCode);
  const codeIndex = memberCol(state.memberDBHeaders, 'code');
  const rawCode = directoryRow && codeIndex >= 0 ? directoryRow[codeIndex] : item.memberCode;
  const digits = normalizedDigits(rawCode);
  return digits ? `id:${digits.replace(/^0+/,'')}` : `name:${norm(item.memberName)}:${norm(item.centerCode)}`;
}
function fillTodayMember() {
  const code = $('#today-member-code').value.trim();
  const row = resolveDirectoryRow(code);
  if (!row) { state.todayRawCenter = ''; state.todayRawMember = ''; updateTodayEntryNote(); renderToday(); return; }
  const ci = memberCol(state.memberDBHeaders, 'center'), ni = memberCol(state.memberDBHeaders, 'name');
  if (ci >= 0) {
    const rawCenter = String(row[ci] || '').split(',')[0].trim();
    state.todayRawCenter = rawCenter;
    $('#today-center-code').value = displayCenterCode(rawCenter);
  }
  if (ni >= 0) $('#today-member-name').value = String(row[ni] || '').trim();
  const codeIndex = memberCol(state.memberDBHeaders, 'code');
  if (codeIndex >= 0) {
    state.todayRawMember = String(row[codeIndex] || '').trim();
    $('#today-member-code').value = displayMemberCode(row[codeIndex]);
  }
  autofillTodayLoan(state.todayRawMember || code);
  updateTodayEntryNote();
  renderToday();
}
/* কিস্তি তালিকায় সদস্য থাকলে ওঁর আজকের/সামনের কিস্তির বাকী অঙ্কটাই লোন ঘরে বসে যায় */
function autofillTodayLoan(code) {
  const loanInput = $('#today-loan');
  if (!loanInput) return;
  const rowIndex = findInstallmentRowForMember(code);
  const d = state.detect;
  const bal = rowIndex >= 0 && d.amount >= 0
    ? Math.max(0, roundMoney(num(state.rows[rowIndex][d.amount]) - num(state.rows[rowIndex][d.actual])))
    : 0;
  if (!loanInput.value || loanInput.dataset.autofill === '1') {
    if (bal > 0) { loanInput.value = String(bal); loanInput.dataset.autofill = '1'; }
    else if (loanInput.dataset.autofill === '1') { loanInput.value = ''; loanInput.dataset.autofill = '0'; }
  }
  renderTodayBalanceCard();
}
/* ফর্মের নিচে ছোট নোট — এই সদস্য মাসিক নাকি অন্যান্য */
function updateTodayEntryNote() {
  const el = $('#today-entry-note');
  if (!el) return;
  const typed = ($('#today-member-code')?.value || '').trim();
  const code = state.todayRawMember || typed;
  if (!code) { el.textContent = ''; el.className = 'today-entry-note'; return; }
  const rowIndex = findInstallmentRowForMember(code);
  const d = state.detect;
  if (rowIndex < 0) {
    el.className = 'today-entry-note other';
    el.textContent = '🗂️ এই সদস্য কিস্তি তালিকায় নেই — এন্ট্রিটি "অন্যান্য আদায়" টেবিলে যাবে।';
    return;
  }
  el.textContent = '';
  el.className = 'today-entry-note hidden';
}
function fillTodayMemberByName() {
  const query=norm($('#today-member-name').value);
  if(!query) return;
  const ni=memberCol(state.memberDBHeaders,'name');
  const matches=state.memberDB.filter(row=>ni>=0&&norm(row[ni])===query);
  if(matches.length!==1) return;
  const row=matches[0], ci=memberCol(state.memberDBHeaders,'center'), ki=memberCol(state.memberDBHeaders,'code');
  if(ci>=0){state.todayRawCenter=String(row[ci]||'').split(',')[0].trim();$('#today-center-code').value=displayCenterCode(state.todayRawCenter);}
  if(ki>=0){state.todayRawMember=String(row[ki]||'').trim();$('#today-member-code').value=displayMemberCode(row[ki]);}
  renderToday();
}
function renderTodayDirectoryOptions() {
  const codeList=$('#today-member-code-options'), nameList=$('#today-member-name-options');
  if(!codeList||!nameList) return;
  const ci=memberCol(state.memberDBHeaders,'code'), ni=memberCol(state.memberDBHeaders,'name');
  const byCode=[...state.memberDB].sort((a,b)=>compareAZ(ci>=0?a[ci]:'',ci>=0?b[ci]:'')||compareAZ(ni>=0?a[ni]:'',ni>=0?b[ni]:''));
  codeList.innerHTML=byCode.map(row=>ci>=0?`<option value="${esc(displayMemberCode(row[ci]))}">${esc(ni>=0?row[ni]:'')}</option>`:'').join('');
  const byName=[...state.memberDB].sort((a,b)=>compareAZ(ni>=0?a[ni]:'',ni>=0?b[ni]:'')||compareAZ(ci>=0?a[ci]:'',ci>=0?b[ci]:''));
  nameList.innerHTML=byName.map(row=>ni>=0?`<option value="${esc(row[ni])}">${esc(ci>=0?displayMemberCode(row[ci]):'')}</option>`:'').join('');
}
function normalizedDigits(value) { return toEn(String(value||'')).replace(/\D/g,''); }
function filteredDirectoryRows() {
  const codeQuery=norm($('#member-db-code-search')?.value||'');
  const centerQuery=norm($('#member-db-center-search')?.value||'');
  const codeIndex=memberCol(state.memberDBHeaders,'code');
  const centerIndex=memberCol(state.memberDBHeaders,'center');
  return state.memberDB.map((row,index)=>({row,index})).filter(({row})=>{
    const code=codeIndex>=0?norm(row[codeIndex]):'';
    const center=centerIndex>=0?norm(row[centerIndex]):'';
    const codeShort=codeIndex>=0?norm(displayMemberCode(row[codeIndex])):'';
    const centerShort=centerIndex>=0?norm(displayCenterCode(String(row[centerIndex]||'').split(',')[0].trim())):'';
    const codeOk=!codeQuery||code.includes(codeQuery)||codeShort.includes(codeQuery);
    const centerOk=!centerQuery||center.includes(centerQuery)||centerShort.includes(centerQuery);
    return codeOk&&centerOk;
  });
}
function renderMemberDatabaseTable() {
  const body=$('#member-db-list'); if(!body) return;
  const codeIndex=memberCol(state.memberDBHeaders,'code');
  const centerIndex=memberCol(state.memberDBHeaders,'center');
  const nameIndex=memberCol(state.memberDBHeaders,'name');
  const mobileIndex=memberCol(state.memberDBHeaders,'mobile');
  const guardianIndex=memberCol(state.memberDBHeaders,'guardian');
  const result=filteredDirectoryRows();
  $('#member-db-count').textContent=state.memberDB.length?`${fmt(result.length)} / ${fmt(state.memberDB.length)} সদস্য · সারির যেকোনো জায়গায় ক্লিক করলে বিস্তারিত খুলবে`:'সদস্য CSV এখনো আপলোড করা হয়নি।';
  const sorted=[...result].sort((a,b)=>compareAZ(codeIndex>=0?a.row[codeIndex]:'',codeIndex>=0?b.row[codeIndex]:'')||compareAZ(nameIndex>=0?a.row[nameIndex]:'',nameIndex>=0?b.row[nameIndex]:''));
  body.innerHTML=sorted.map(({row,index})=>`<tr class="member-db-row" data-member-db-index="${index}" tabindex="0" role="button">
      <td>${esc(displayMemberCode(row[codeIndex]||''))}</td><td>${esc(displayCenterCode(String(row[centerIndex]||'').split(',')[0].trim()))}</td>
    <td>${esc(row[nameIndex]||'')}</td><td>${esc(safeTelephone(row[mobileIndex]||'')||'—')}</td><td>${esc(row[guardianIndex]||'—')}</td></tr>`).join('');
  $('#member-db-empty').classList.toggle('hidden',result.length>0);
  $('.member-db-table').classList.toggle('hidden',result.length===0);
}
function openDirectoryMemberDetails(index) {
  const row=state.memberDB[index]; if(!row) return;
  const codeIndex=memberCol(state.memberDBHeaders,'code');
  const mobileIndex=memberCol(state.memberDBHeaders,'mobile');
  const code=displayMemberCode(codeIndex>=0?row[codeIndex]:'');
  const nameIndex=memberCol(state.memberDBHeaders,'name');
  const entries=formatMemberDetails(state.memberDBHeaders.map((header,i)=>({label:header,value:row[i]||''})),codeIndex);
  openMemberDetails(entries,mobileIndex>=0?row[mobileIndex]:'',[code,nameIndex>=0?row[nameIndex]:''].filter(Boolean).join(' · '));
}

function currentMemberBalance(memberCode, memberName, centerCode) {
  const idIndex=state.balanceHeaders.findIndex(h=>normHeader(h).includes('memberid'));
  const nameIndex=state.balanceHeaders.findIndex(h=>normHeader(h).includes('nameofmember')||normHeader(h).includes('membername'));
  const centerDigits=normalizedDigits(centerCode);
  const directoryRow = resolveDirectoryRow(memberCode, centerCode);
  const directoryCodeIndex = memberCol(state.memberDBHeaders, 'code');
  const id=normalizedDigits(directoryRow && directoryCodeIndex >= 0 ? directoryRow[directoryCodeIndex] : memberCode);
  let candidates=state.balanceRows.filter(r=>{
    const rid=normalizedDigits(r[idIndex]);
    return rid && id && (id===rid || id.endsWith(rid) || rid.endsWith(id));
  });
  if(candidates.length>1){
    const exact=candidates.filter(r=>normalizedDigits(r[idIndex])===id);
    if(exact.length===1){candidates=exact;}
    else{
      const longest=candidates.filter(r=>normalizedDigits(r[idIndex]).length>=id.length);
      if(longest.length===1)candidates=longest;
    }
  }
  if(centerDigits && candidates.length>1){ const same=candidates.filter(r=>normalizedDigits(r[state.balanceHeaders.length])===centerDigits); if(same.length) candidates=same; }
  if(!candidates.length && nameIndex>=0 && memberName){
    const n=norm(memberName).replace(/[^a-z0-9]/g,'');
    candidates=state.balanceRows.filter(r=>norm(r[nameIndex]).replace(/[^a-z0-9]/g,'')===n && (!centerDigits || !r[state.balanceHeaders.length] || normalizedDigits(r[state.balanceHeaders.length])===centerDigits));
  }
  if(!candidates.length) return null;
  const row=candidates[0];
  const savingsIndex=state.balanceHeaders.findIndex(h=>/savings.*(outstanding|balance)/.test(normHeader(h)));
  const loanIndex=state.balanceHeaders.findIndex(h=>/loan.*(outstanding|balance)/.test(normHeader(h)));
  const dpsIndex=state.balanceHeaders.findIndex(h=>/dps.*(outstanding|balance)|deposit.*(outstanding|balance)/.test(normHeader(h)));
  return {loan:loanIndex>=0?num(row[loanIndex]):0,savings:savingsIndex>=0?num(row[savingsIndex]):0,dps:dpsIndex>=0?num(row[dpsIndex]):0};
}
/* Today All Collection-এর স্থিতি কার্ড — ২ লাইনে:
   ১ম লাইন = পূর্বের স্থিতি (CSV থেকে), ২য় লাইন = এন্ট্রি পরে স্থিতি
   (আজকের সেভ করা এন্ট্রি + এখন টাইপ করা অঙ্গ — সেভ করার আগেই লাইভ দেখায়)। */
function installmentChips(code) {
  const rowIndex = findInstallmentRowForMember(code);
  if (rowIndex < 0) return '<span class="balance-chip installment other">🗂️ অন্যান্য আদায়<b>কিস্তি তালিকায় নেই</b></span>';
  const row = state.rows[rowIndex], d = state.detect;
  const amount = d.amount >= 0 ? num(row[d.amount]) : 0;
  const st = rowStatus(row);
  const tone = st === 'paid' ? 'paid' : st === 'partial' ? 'partial' : 'due';
  return `<span class="balance-chip installment ${tone}">📅 ${shortDate(String(row[d.date] ?? ''))}</span>`
    + `<span class="balance-chip installment ${tone}">কিস্তি<b>৳ ${fmt(amount)}</b></span>`;
}

function renderTodayBalanceCard() {
  const el = $('#today-balance-summary');
  if (!el) return;
  const typedCode = $('#today-member-code')?.value.trim() || '';
  const typedCenter = $('#today-center-code')?.value.trim() || '';
  const code = state.todayRawMember || typedCode;
  const centerHint = state.todayRawCenter || typedCenter;
  const row = resolveDirectoryRow(code, centerHint);
  const typed = {
    loan: num($('#today-loan')?.value),
    savings: num($('#today-savings')?.value),
    dps: num($('#today-dps')?.value),
  };
  const typedTotal = roundMoney(typed.loan + typed.savings + typed.dps);
  const chip = (kind, label, value) => `<span class="balance-chip ${kind}">${label}<b>${value}</b></span>`;

  if (!code) {
    el.innerHTML = `<div class="balance-card is-empty">${state.balanceRows.length
      ? `পূর্বের স্থিতির CSV লোড আছে (${fmt(state.balanceRows.length)} সারি)। মেম্বার কোড লিখুন।`
      : 'মেম্বার কোড লিখে সদস্য ও পূর্বের স্থিতি দেখুন।'}</div>`;
    return;
  }

  const ci = memberCol(state.memberDBHeaders, 'center');
  const ni = memberCol(state.memberDBHeaders, 'name');
  const name = row && ni >= 0 ? String(row[ni] || '').trim() : ($('#today-member-name')?.value.trim() || '');
  const centerCode = row && ci >= 0 ? String(row[ci] || '').split(',')[0].trim() : centerHint;
  const base = currentMemberBalance(code, name, centerCode);
  const key = dailyAccountKey({ memberCode: code, memberName: name, centerCode: centerCode });
  const saved = state.todayRows
    .filter((item) => dailyAccountKey(item) === key)
    .reduce((acc, item) => ({
      loan: acc.loan + num(item.loan),
      savings: acc.savings + num(item.savings),
      dps: acc.dps + num(item.dps),
    }), { loan: 0, savings: 0, dps: 0 });
  const after = base ? {
    loan: roundMoney(base.loan - saved.loan - typed.loan),
    savings: roundMoney(base.savings + saved.savings + typed.savings),
    dps: roundMoney(base.dps + saved.dps + typed.dps),
  } : null;
  const money = (value) => (base ? `৳ ${fmt(value)}` : '—');

  el.innerHTML = `<div class="balance-card">
      <div class="balance-line">
        <span class="balance-tag">পূর্বের স্থিতি</span>
        <div class="balance-chips">
          ${chip('loan', 'লোন ', money(base ? base.loan : 0))}
          ${chip('savings', 'সঞ্চয় ', money(base ? base.savings : 0))}
          ${chip('dps', 'DPS ', money(base ? base.dps : 0))}
          ${installmentChips(code)}
        </div>
        ${base ? '' : '<span class="balance-note">পূর্বের স্থিতি CSV-তে পাওয়া যায়নি</span>'}
      </div>
      <div class="balance-line after">
        <span class="balance-tag">এন্ট্রি পরে স্থিতি</span>
        <div class="balance-chips">
          ${chip('loan', 'লোন ', money(after ? after.loan : 0))}
          ${chip('savings', 'সঞ্চয় ', money(after ? after.savings : 0))}
          ${chip('dps', 'DPS ', money(after ? after.dps : 0))}
          ${typedTotal > 0 ? `<span class="balance-chip pending">নতুন এন্ট্রি<b>৳ ${fmt(typedTotal)}</b></span>` : ''}
        </div>
      </div>
    </div>`;
}

/* সদস্য কোড মিলিয়ে কিস্তি তালিকার সারি খোঁজা — Today পেজ থেকে আদায় নিলে ওই সারিই আপডেট হয় */
const memberCodeKey = (value) => normalizedDigits(value).replace(/^0+/, '');
function findInstallmentRowForMember(code) {
  const d = state.detect;
  const key = memberCodeKey(code);
  if (!key || d.memberCode < 0) return -1;
  const matches = [];
  state.rows.forEach((row, index) => { if (memberCodeKey(row[d.memberCode]) === key) matches.push(index); });
  if (!matches.length) return -1;
  const today = localDateInputValue();
  const open = matches.filter((i) => ['due', 'partial'].includes(rowStatus(state.rows[i])));
  const todaysOpen = open.filter((i) => rowDateISO(state.rows[i]) === today);
  if (todaysOpen.length) return todaysOpen[0];
  if (open.length) {
    const dated = open.filter((i) => rowDateISO(state.rows[i]));
    if (dated.length) return dated.sort((a, b) => compareAZ(rowDateISO(state.rows[a]), rowDateISO(state.rows[b])))[0];
    return open[0];
  }
  return matches[0];
}
function findRowByInstallmentKey(key) {
  if (!key) return -1;
  return state.rows.findIndex((row) => installmentRowKey(row) === key);
}
// এই এন্ট্রিটি "মাসিক আদায়" কি না — কিস্তি তালিকায় ওই সদস্য আছেন কি না
function isMonthlyEntry(item) {
  if (!item) return false;
  if (item.installmentKey) return true;
  return findInstallmentRowForMember(item.memberCode) >= 0;
}

function renderToday() {
  const monthlyBody = $('#today-monthly-list'), otherBody = $('#today-other-list');
  if (!monthlyBody || !otherBody) return;
  renderTodayDirectoryOptions();
  $('#today-count-badge').textContent = fmt(state.todayRows.length);

  // "এন্ট্রি পরে স্থিতি" — সব এন্ট্রি মিলিয়ে (মাসিক + অন্যান্য) ক্রমানুসারে হিসাব
  const ordered = state.todayRows.map((item, index) => ({ item, index }))
    .sort((a, b) => String(a.item.createdAt || '').localeCompare(String(b.item.createdAt || '')) || b.index - a.index);
  const running = new Map(), afterByIndex = new Map();
  for (const { item, index } of ordered) {
    const key = dailyAccountKey(item); let totals = running.get(key);
    if (!totals) { const base = currentMemberBalance(item.memberCode, item.memberName, item.centerCode); totals = { known: !!base, loan: base?.loan || 0, savings: base?.savings || 0, dps: base?.dps || 0 }; }
    totals.loan = roundMoney(totals.loan - num(item.loan)); totals.savings = roundMoney(totals.savings + num(item.savings)); totals.dps = roundMoney(totals.dps + num(item.dps));
    running.set(key, totals); afterByIndex.set(index, { ...totals });
  }

  const rowsWithIndex = state.todayRows.map((item, index) => ({ item, index }))
    .sort((a, b) => compareMemberCodes(a.item.memberCode, b.item.memberCode) || compareAZ(a.item.createdAt, b.item.createdAt));
  const monthly = rowsWithIndex.filter(({ item }) => isMonthlyEntry(item));
  const others = rowsWithIndex.filter(({ item }) => !isMonthlyEntry(item));

  const paint = (tbody, list) => {
    tbody.innerHTML = list.map(({ item, index }, position) => {
      const b = afterByIndex.get(index); const bal = (v) => (b?.known ? fmt(v) : '—');
      return `<tr class="today-row" data-today-index="${index}" tabindex="0" role="button">
    <td>${fmt(position + 1)}</td><td>${esc(displayMemberCode(item.memberCode))}</td><td>${esc(displayCenterCode(item.centerCode))}</td><td>${esc(item.memberName)}</td>
    <td class="amt">${fmt(item.loan)}</td><td class="amt">${fmt(item.savings)}</td><td class="amt">${fmt(item.dps)}</td><td class="amt">৳ ${fmt(item.total)}</td>
    <td class="amt">${bal(b?.loan)}</td><td class="amt">${bal(b?.savings)}</td><td class="amt">${bal(b?.dps)}</td>
    <td class="row-actions"><button type="button" class="mini-btn edit" data-edit-today="${index}" title="এই এন্ট্রি এডিট করুন">✏️</button><button type="button" class="mini-btn del" data-del-today="${index}" title="এই এন্ট্রি মুছে ফেলুন">🗑️</button></td></tr>`;
    }).join('');
  };
  paint(monthlyBody, monthly);
  paint(otherBody, others);

  const closeBtn = $('#btn-close-today');
  if (closeBtn) {
    closeBtn.disabled = state.todayRows.length === 0;
    closeBtn.title = state.todayRows.length === 0
      ? 'ক্লোজ করার মতো এন্ট্রি নেই'
      : `${fmt(state.todayRows.length)}টি এন্ট্রি হিসাব ক্লোজ করে খাতায় জমা করুন`;
  }
  const todayIso = localDateInputValue();
  const oldEntries = state.todayRows.filter((item) => String(item.date || '').slice(0, 10) !== todayIso).length;
  if ($('#today-old-note')) {
    $('#today-old-note').textContent = oldEntries
      ? `⚠️ ${fmt(oldEntries)}টি এন্ট্রি আগের তারিখের — "হিসাব ক্লোজ" করলে ওই তারিখেই জমা হবে।`
      : '';
    $('#today-old-note').classList.toggle('hidden', oldEntries === 0);
  }
  const setText = (sel, text) => { const el = $(sel); if (el) el.textContent = text; };
  setText('#count-today-monthly', fmt(monthly.length));
  setText('#count-today-other', fmt(others.length));
  const toggleEmpty = (sel, isEmpty) => { const el = $(sel); if (el) el.classList.toggle('hidden', !isEmpty); };
  toggleEmpty('#today-monthly-empty', monthly.length === 0);
  toggleEmpty('#today-other-empty', others.length === 0);
  renderTodayBalanceCard();
}
/* ---------- Today All Collection: এন্ট্রি এডিট / ডিলিট ---------- */
function revertAppliedLoan(item, d = state.detect) {
  if (!item) return false;
  const applied = num(item.appliedLoan);
  if (!(applied > 0) || d.actual < 0) return false;
  let rowIndex = findRowByInstallmentKey(item.installmentKey);
  if (rowIndex < 0) rowIndex = findInstallmentRowForMember(item.memberCode);
  if (rowIndex < 0) return false;
  const row = state.rows[rowIndex];
  row[d.actual] = String(roundMoney(Math.max(0, num(row[d.actual]) - applied)));
  return true;
}
async function deleteTodayRow(index) {
  const item = state.todayRows[index];
  if (!item) return;
  const label = item.memberName + ' — ৳ ' + fmt(item.total);
  if (!window.confirm('এই এন্ট্রিটা মুছে ফেলবেন?\n\n' + label + '\n\nকিস্তি তালিকায় যে টাকা যোগ হয়েছিল সেটাও ফিরে যাবে।')) return;
  const snapshot = { todayRows: state.todayRows.map((x) => ({ ...x })), rows: state.rows.map((r) => [...r]) };
  state.todayRows.splice(index, 1);
  revertAppliedLoan(item);
  if (state.editingToday === index) cancelTodayEdit(true);
  else if (state.editingToday > index) state.editingToday -= 1;
  renderTables(); renderToday();
  try {
    await persistRows();
    toast('🗑️ এন্ট্রি মুছে ফেলা হয়েছে');
  } catch (e) {
    state.todayRows = snapshot.todayRows;
    state.rows = snapshot.rows;
    state.detect = detectColumns(state.headers);
    renderTables(); renderToday();
    toast('⚠️ মুছে ফেলা সেভ হয়নি: ' + e.message, true);
  }
}
function startEditToday(index) {
  const item = state.todayRows[index];
  if (!item) return;
  state.editingToday = index;
  state.todayRawMember = String(item.memberCode ?? '');
  state.todayRawCenter = String(item.centerCode ?? '');
  const set = (sel, value) => { const el = $(sel); if (el) el.value = value; };
  set('#today-member-code', displayMemberCode(item.memberCode));
  set('#today-center-code', displayCenterCode(item.centerCode));
  set('#today-member-name', item.memberName ?? '');
  set('#today-loan', item.loan ?? 0);
  set('#today-savings', item.savings ?? 0);
  set('#today-dps', item.dps ?? 0);
  const loanInput = $('#today-loan');
  if (loanInput) loanInput.dataset.autofill = '0';
  renderTodayBalanceCard();
  updateTodayEntryNote();
  const btn = $('#btn-add-today');
  if (btn) { btn.textContent = '💾 এন্ট্রি আপডেট'; btn.classList.add('editing'); }
  const cancel = $('#btn-cancel-edit');
  if (cancel) cancel.classList.remove('hidden');
  renderToday();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function cancelTodayEdit(silent = false) {
  state.editingToday = -1;
  const btn = $('#btn-add-today');
  if (btn) { btn.textContent = '＋ তালিকায় যোগ'; btn.classList.remove('editing'); }
  const cancel = $('#btn-cancel-edit');
  if (cancel) cancel.classList.add('hidden');
  clearTodayForm();
  renderToday();
  if (!silent) toast('এডিট বাতিল হয়েছে');
}

/* ---------- দিনের হিসাব ক্লোজ: এন্ট্রি তারিখভিত্তিক স্থায়ী খাতায় জমা ---------- */
async function closeTodayAccount() {
  if (!state.todayRows.length) { toast('হিসাব ক্লোজ করার মতো কোনো এন্ট্রি নেই।'); return; }
  const closedAt = new Date().toISOString();
  const closeDate = localDateInputValue();
  const total = state.todayRows.reduce((sum, item) => sum + num(item.total), 0);
  if (!window.confirm(`আজকের ${fmt(state.todayRows.length)}টি এন্ট্রি (মোট ৳ ${fmt(total)}) হিসাব ক্লোজ করে তারিখভিত্তিক খাতায় জমা করবেন?\n\nকিস্তির আদায় অপরিবর্তিত থাকবে — শুধু Today পেজের তালিকা খালি হবে।\nখাতার হিসাব কখনো মুছবে না (তারিখ দিয়ে ফিল্টার করে দেখা যাবে)।`)) return;
  const entries = state.todayRows.map((item) => ({
    id: uid(),
    date: String(item.date || closeDate).slice(0, 10),
    closeDate,
    closedAt,
    kind: isMonthlyEntry(item) ? 'monthly' : 'other',
    memberCode: String(item.memberCode ?? ''),
    centerCode: String(item.centerCode ?? ''),
    memberName: String(item.memberName ?? ''),
    installmentKey: String(item.installmentKey || ''),
    loan: roundMoney(num(item.loan)),
    savings: roundMoney(num(item.savings)),
    dps: roundMoney(num(item.dps)),
    total: roundMoney(num(item.total)),
  }));
  const oldRows = [...state.todayRows], oldHistory = [...state.history];
  state.history = [...entries, ...state.history];
  state.todayRows = [];
  renderToday(); renderHistory(); updateTodayEntryNote();
  try {
    await persistRows(); state.lastSync = new Date();
    if ($('#history-date')) $('#history-date').value = closeDate;
    renderHistory();
    toast(`✅ হিসাব ক্লোজ হয়েছে — ${fmt(entries.length)}টি এন্ট্রি ৳ ${fmt(total)} তারিখভিত্তিক খাতায় জমা হলো`);
  } catch (e) {
    state.todayRows = oldRows; state.history = oldHistory;
    renderToday(); renderHistory(); toast('⚠️ ক্লোজ সিঙ্ক হয়নি: ' + e.message, true);
  }
}

function filteredHistory() {
  const date = ($('#history-date')?.value || '').trim();
  return state.history.filter((item) => !date || String(item.date || '') === date);
}

function renderHistory() {
  const tbody = $('#history-list'); if (!tbody) return;
  const items = [...filteredHistory()]
    .sort((a, b) => compareAZ(a.date, b.date) || compareMemberCodes(a.memberCode, b.memberCode) || compareAZ(a.memberName, b.memberName));
  const totals = items.reduce((out, item) => {
    out.loan += num(item.loan); out.savings += num(item.savings); out.dps += num(item.dps); out.total += num(item.total);
    if (item.kind === 'monthly') out.monthly += num(item.total); else out.other += num(item.total);
    return out;
  }, { loan: 0, savings: 0, dps: 0, total: 0, monthly: 0, other: 0 });

  const dateInput = $('#history-date');
  const filterLabel = dateInput && dateInput.value ? shortDate(dateInput.value) : 'সব তারিখ';
  const setText = (sel, text) => { const el = $(sel); if (el) el.textContent = text; };
  setText('#count-history', fmt(items.length));
  setText('#history-filter-label', filterLabel);
  if ($('#history-summary')) {
    $('#history-summary').innerHTML = `
      <div class="history-stat"><span>এন্ট্রি</span><strong>${fmt(items.length)}</strong></div>
      <div class="history-stat monthly"><span>মাসিক আদায়</span><strong>৳ ${fmt(totals.monthly)}</strong></div>
      <div class="history-stat other"><span>অন্যান্য আদায়</span><strong>৳ ${fmt(totals.other)}</strong></div>
      <div class="history-stat total"><span>মোট আদায়</span><strong>৳ ${fmt(totals.total)}</strong></div>`;
  }
  tbody.innerHTML = items.map((item) => `<tr class="${item.kind === 'monthly' ? 'history-monthly' : 'history-other'}">
    <td>${esc(shortDate(item.date))}</td>
    <td><span class="kind-chip ${item.kind === 'monthly' ? 'monthly' : 'other'}">${item.kind === 'monthly' ? '📅 মাসিক' : '🗂️ অন্যান্য'}</span></td>
    <td>${esc(displayMemberCode(item.memberCode) || '—')}</td>
    <td>${esc(displayCenterCode(item.centerCode) || '—')}</td>
    <td class="history-name">${esc(item.memberName || '—')}</td>
    <td class="amt">${fmt(num(item.loan))}</td>
    <td class="amt">${fmt(num(item.savings))}</td>
    <td class="amt">${fmt(num(item.dps))}</td>
    <td class="amt history-total">৳ ${fmt(num(item.total))}</td>
  </tr>`).join('');
  const empty = $('#history-empty');
  if (empty) {
    empty.textContent = state.history.length
      ? `${filterLabel} তারিখে কোনো হিসাব নেই।`
      : 'এখনো কোনো হিসাব ক্লোজ করা হয়নি — "✔️ হিসাব ক্লোজ" চাপলে আজকের এন্ট্রি এখানে জমা হবে।';
    empty.classList.toggle('hidden', items.length > 0);
  }
  const table = $('#history-table');
  if (table) table.classList.toggle('hidden', items.length === 0);
}

/* এন্ট্রি ফর্মের সব ঘর ফাঁকা (তালিকা বা কিস্তির ডেটা অপরিবর্তিত) */
function clearTodayForm() {
  ['today-member-code','today-center-code','today-member-name','today-loan','today-savings','today-dps'].forEach((id) => {
    const el = $('#' + id); if (el) el.value = '';
  });
  const savings = $('#today-savings'); if (savings) savings.value = '0';
  const dps = $('#today-dps'); if (dps) dps.value = '0';
  const loan = $('#today-loan'); if (loan) loan.dataset.autofill = '0';
  state.todayRawMember = ''; state.todayRawCenter = '';
  updateTodayEntryNote();
  renderTodayBalanceCard();
}

async function addTodayRow() {
  const typedCode = $('#today-member-code').value.trim();
  const typedCenter = $('#today-center-code').value.trim();
  const code = state.todayRawMember || typedCode;
  const centerCode = state.todayRawCenter || typedCenter;
  const memberName = $('#today-member-name').value.trim();
  const loan = roundMoney(num($('#today-loan').value));
  const savings = roundMoney(num($('#today-savings').value));
  const dps = roundMoney(num($('#today-dps').value));
  if (!code || !memberName) { toast('মেম্বার কোড ও নাম লিখুন।', true); return; }
  if ([loan,savings,dps].some((v)=>v<0) || loan+savings+dps<=0) { toast('সঠিক আদায়ের পরিমাণ লিখুন।', true); return; }
  const editingIndex = Number.isInteger(state.editingToday) ? state.editingToday : -1;

  const d = state.detect;
  const match = resolveDirectoryRow(code) || findDirectoryMember(typedCode);
  // কিস্তি তালিকায় এই সদস্য থাকলে → ওই সারিতে আদায় বসবে (বাকী/আংশিক → আদায় কিস্তি)
  const rowIndex = findInstallmentRowForMember(code);
  const installmentKey = rowIndex >= 0 ? installmentRowKey(state.rows[rowIndex]) : '';
  const prevActual = rowIndex >= 0 && d.actual >= 0 ? String(state.rows[rowIndex][d.actual] ?? '') : '';

  const previousRows = [...state.todayRows];
  const oldFollowups = [...state.followups];
  const previousRowCells = state.rows.map((r) => [...r]);
  let clearedFollowup = false;
  const editingItem = editingIndex >= 0 ? state.todayRows[editingIndex] : null;
  if (editingItem) revertAppliedLoan(editingItem, d);
  if (rowIndex >= 0 && loan > 0 && d.actual >= 0) {
    const row = state.rows[rowIndex];
    row[d.actual] = String(roundMoney(num(row[d.actual]) + loan));
    // পুরো কিস্তি শোধ হলে (বাকী → আদায় বা আংশিক → আদায়) প্রতিশ্রুতি/পরবর্তী তারিখ স্বয়ংক্রিয়ভাবে মুছে যায়
    if (num(row[d.actual]) >= num(row[d.amount])) {
      const key = followupKey(row);
      clearedFollowup = state.followups.some((item) => item.key === key);
      if (clearedFollowup) state.followups = state.followups.filter((item) => item.key !== key);
    }
  }
  const entry = {
    memberCode: code, centerCode, memberName, loan, savings, dps,
    total: roundMoney(loan + savings + dps), date: localDateInputValue(), createdAt: new Date().toISOString(),
    memberIndex: match ? state.memberDB.indexOf(match) : -1,
    installmentKey, appliedLoan: rowIndex >= 0 && loan > 0 && d.actual >= 0 ? loan : 0, prevActual,
  };
  if (editingItem) {
    entry.date = editingItem.date || entry.date;
    entry.createdAt = editingItem.createdAt || entry.createdAt;
    state.todayRows[editingIndex] = entry;
  } else {
    state.todayRows.unshift(entry);
  }
  state.todayRawMember = ''; state.todayRawCenter = '';
  renderTables(); renderToday();
  try {
    await persistRows();
    if (editingItem) { state.editingToday = -1; const b = $('#btn-add-today'); if (b) { b.textContent = '＋ তালিকায় যোগ'; b.classList.remove('editing'); } const c = $('#btn-cancel-edit'); if (c) c.classList.add('hidden'); }
    clearTodayForm(); renderToday();
    const fullPaid = installmentKey && num(prevActual) + loan >= num(state.rows[rowIndex]?.[d.amount]);
    toast(installmentKey
      ? (fullPaid
        ? `✅ পুরো কিস্তি শোধ — সদস্য আদায় কিস্তিতে চলে গেছেন${clearedFollowup ? ' · প্রতিশ্রুতি মুছে গেছে' : ''}`
        : `✅ আংশিক আদায় সেভ — সদস্য আংশিকে আছেন, বাকী ৳ ${fmt(Math.max(0, num(state.rows[rowIndex]?.[d.amount]) - num(prevActual) - loan))}`)
      : '✅ এন্ট্রি Neon-এ সেভ হয়েছে—সব ডিভাইসে দেখা যাবে');
  } catch(e) {
    state.todayRows = previousRows;
    state.followups = oldFollowups;
    state.rows = previousRowCells;
    state.detect = detectColumns(state.headers);
    renderTables(); renderToday(); toast('⚠️ এন্ট্রি সিঙ্ক হয়নি: '+e.message,true);
  }
}
function openTodayDetails(index) {
  const item = state.todayRows[index]; if (!item) return;
  const row = findDirectoryMember(item.memberCode);
  const entries = row ? formatMemberDetails(state.memberDBHeaders.map((header,i)=>({label:header,value:row[i]})), memberCol(state.memberDBHeaders,'code')) : [];
  entries.unshift({label:'আজকের লোন',value:fmt(item.loan)},{label:'আজকের সঞ্চয়',value:fmt(item.savings)},{label:'আজকের DPS',value:fmt(item.dps)},{label:'আজকের মোট',value:fmt(item.total)});
  const baseline=currentMemberBalance(item.memberCode,item.memberName,item.centerCode);
  if(baseline){const sums=state.todayRows.filter(x=>dailyAccountKey(x)===dailyAccountKey(item)).reduce((a,x)=>({loan:a.loan+num(x.loan),savings:a.savings+num(x.savings),dps:a.dps+num(x.dps)}),{loan:0,savings:0,dps:0});entries.unshift({label:'সর্বশেষ লোন স্থিতি',value:fmt(baseline.loan-sums.loan)},{label:'সর্বশেষ সঞ্চয় স্থিতি',value:fmt(baseline.savings+sums.savings)},{label:'সর্বশেষ DPS স্থিতি',value:fmt(baseline.dps+sums.dps)});}
  const mi=memberCol(state.memberDBHeaders,'mobile'); const mobile=row&&mi>=0?row[mi]:'';
  openMemberDetails(stripHiddenDetails(entries),mobile,`${item.memberCode} · ${item.memberName}`);
}
function importMemberCSV(file) {
  parseReportFile(file).then((fileRows)=>{
    let old=null;
    return (async()=>{
    try {
      const rules=window.COLLECTION_CSV;
      if(!rules)throw new Error('সিঙ্ক ফাইল লোড হয়নি—পেজটি একবার রিফ্রেশ করুন।');
      const parsed=rules.parseMemberRows(fileRows.rows);
      const headers=parsed.headers;const rows=parsed.rows;const stats=parsed.stats;
      old={headers:state.memberDBHeaders,rows:state.memberDB};state.memberDBHeaders=headers;state.memberDB=rows;
      await persistRows();
      const breakdown=Object.entries(stats.statusCounts).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`${k} ${fmt(v)}`).join(' · ');
      $('#member-csv-status').innerHTML=`✅ <b>${fmt(rows.length)}</b> সদস্য Neon-এ সিঙ্ক হয়েছে—সব ডিভাইসে পাওয়া যাবে।<br>${breakdown?breakdown+' · ':''}${stats.centers?fmt(stats.centers)+' সেন্টার · ':''}${stats.withGuardian?`পিতা/স্বামী/অভিভাবক ${fmt(stats.withGuardian)} জনের আছে`:''}`;
      $('#member-csv-modal').classList.remove('hidden');updateModalScrollLock();renderToday();renderMemberDatabaseTable();toast('✅ সদস্য CSV সব ডিভাইসে সিঙ্ক হয়েছে');
    } catch(e) {
      if(typeof old!=='undefined'){state.memberDBHeaders=old.headers;state.memberDB=old.rows;}
      $('#member-csv-status').textContent='⚠️ '+e.message;$('#member-csv-modal').classList.remove('hidden');updateModalScrollLock();
    }
    })();
  }).catch((e)=>{
    $('#member-csv-status').textContent='⚠️ '+e.message;$('#member-csv-modal').classList.remove('hidden');updateModalScrollLock();
  });
}
/* পূর্বের স্থিতির CSV — দুই ধরনের ফরম্যাট সমর্থন করে:
   ১) নতুন: Member ID | Member Name | Savings Balance | DPS Balance | Loan Balance
      (+ "Item Code: XX.XX Item Name: …" লোন-প্রোডাক্ট গ্রুপ সারি, একই সদস্যের একাধিক প্রোডাক্টের সারি যোগ করা হয়)
   ২) পুরোনো: Member ID | Name of Member | Savings Outstanding Balance | Loan Outstanding
      (+ "Samity: 0001, …" সেন্টার সারি — প্রতিটি সারি আলাদা রাখা হয়) */
function findBalanceHeaderRow(rows) {
  return rows.findIndex((row) => {
    const headers = row.map(normHeader);
    const hasId = headers.some((h) => h.includes('memberid') || h.includes('membercode') || h.includes('memberno'));
    const hasName = headers.some((h) => h.includes('nameofmember') || h.includes('membername'));
    const hasBalance = headers.some((h) => (h.includes('loan') && (h.includes('outstanding') || h.includes('balance')))
      || (h.includes('savings') && (h.includes('outstanding') || h.includes('balance'))));
    return hasId && hasName && hasBalance;
  });
}
function importBalanceCSV(file) {
  parseReportFile(file).then((fileRows)=>{
    let old=null;
    return (async()=>{
    try {
      const rules=window.COLLECTION_CSV;
      if(!rules)throw new Error('সিঙ্ক ফাইল লোড হয়নি—পেজটি একবার রিফ্রেশ করুন।');
      const parsed=rules.parseBalanceRows(fileRows.rows);
      const headers=parsed.headers;const rows=parsed.rows;const stats=parsed.stats;
      old={headers:state.balanceHeaders,rows:state.balanceRows};state.balanceHeaders=headers;state.balanceRows=rows;
      await persistRows();
      const totals=stats.totals;
      $('#balance-csv-status').innerHTML=`✅ <b>${fmt(stats.members)}</b> জনের স্থিতি Neon-এ সিঙ্ক হয়েছে (${fmt(stats.records)} সারি থেকে)।<br>মোট লোন ৳ ${fmt(totals.loan)} · সঞ্চয় ৳ ${fmt(totals.savings)} · DPS ৳ ${fmt(totals.dps)}${stats.hasDps?'':' — <b>ফাইলে DPS কলাম নেই, পূর্বের DPS ০ ধরা হয়েছে</b>'}`;
      $('#member-csv-modal').classList.remove('hidden');updateModalScrollLock();renderToday();toast('✅ পূর্বের স্থিতি সব ডিভাইসে সিঙ্ক হয়েছে');
    } catch(e) {
      if(old){state.balanceHeaders=old.headers;state.balanceRows=old.rows;}
      $('#balance-csv-status').textContent='⚠️ '+e.message;$('#member-csv-modal').classList.remove('hidden');updateModalScrollLock();
    }
    })();
  }).catch((e)=>{
    $('#balance-csv-status').textContent='⚠️ '+e.message;$('#member-csv-modal').classList.remove('hidden');updateModalScrollLock();
  });
}
/* ============================================================
   MIS ফাইল একসাথে আপলোড — CSV · লেগ্য .xls · HTML (যেকোনো ফরম্যাটে আসুক)
   gBanker থেকে ডাউনলোড করা তিনটি ফাইল এক জায়গায় বাছলেই
   কিস্তির তালিকা · সদস্য তালিকা · পূর্বের স্থিতি — তিনটি ডেটাবেজই আপডেট হয়।
   কোন ফাইলটি কী রিপোর্ট, তা ফাইলের হেডার দেখে নিজে থেকেই চেনা হয়।
   ============================================================ */
const misSlots = { installment: null, member: null, balance: null };
const MIS_SLOT_LABEL = { installment: '① কিস্তির তালিকা', member: '② সদস্য তালিকা', balance: '③ পূর্বের স্থিতি' };
const MIS_FORMAT_LABEL = { xls: 'লেগ্য .xls', html: 'HTML', csv: 'CSV' };

function readFileBytes(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(new Uint8Array(reader.result));
    reader.onerror = () => reject(new Error('ফাইলটি পড়া যায়নি।'));
    reader.readAsArrayBuffer(file);
  });
}
/* যেকোনো ফরম্যাটের ফাইল পড়ে সারি বের করে + কী রিপোর্ট তা শনাক্ত করে */
async function parseReportFile(file) {
  const rules = window.COLLECTION_CSV;
  if (!rules) throw new Error('পার্সিং ফাইল লোড হয়নি — পেজটি একবার রিফ্রেশ করুন।');
  const bytes = await readFileBytes(file);
  const { rows, format } = rules.readReportRows(bytes);
  const detected = rules.detectReportType(rows);
  return { rows, format, type: detected.type, headerIndex: detected.headerIndex, name: file.name || 'ফাইল' };
}
function renderMisSlots() {
  ['installment', 'member', 'balance'].forEach((slot) => {
    const el = $('#mis-status-' + slot);
    if (!el) return;
    const item = misSlots[slot];
    if (!item) { el.innerHTML = '<span class="miss">— ফাইল বাছা হয়নি</span>'; return; }
    const fmtLabel = MIS_FORMAT_LABEL[item.format] || item.format;
    el.innerHTML = `✅ <b>${esc(item.name)}</b><br>${esc(MIS_SLOT_LABEL[slot])} · ${esc(fmtLabel)} · ${fmt(item.rows.length)} সারি`;
  });
  const btn = $('#btn-apply-mis-files');
  if (btn) btn.disabled = !Object.values(misSlots).some(Boolean);
}
/* ফাইল বেছে নিলে সাথে সাথে পড়ে দেখায় — কোনটি কী রিপোর্ট তা লেখা থাকে */
async function handleMisFile(file) {
  const status = $('#mis-upload-status');
  try {
    const parsed = await parseReportFile(file);
    if (!parsed.type) throw new Error(`"${parsed.name}" ফাইলটি কোন রিপোর্ট বোঝা যায়নি।`);
    misSlots[parsed.type] = { ...parsed, slot: parsed.type };
    renderMisSlots();
    if (status) status.innerHTML = `📄 <b>${esc(parsed.name)}</b> পড়া হয়েছে — ${esc(MIS_FORMAT_LABEL[parsed.format] || parsed.format)} · ${esc(MIS_SLOT_LABEL[parsed.type])}।`;
  } catch (e) {
    if (status) status.innerHTML = `⚠️ ${esc(e.message)}`;
  }
}
/* সংগ্রহ-রিপোর্টের পাতলা তালিকা (নাম + কোড + সেন্টার) আগের ডাটাবেজে মিলিয়ে দেয় */
function mergeThinMemberList(oldRows, oldHeaders, newRows, newHeaders) {
  const last4v = (v) => String(v ?? '').replace(/\D/g, '').slice(-4);
  const findCol = (headers, test) => (headers || []).findIndex((h) => test(normHeader(h)));
  const oCode = findCol(oldHeaders, (h) => h.includes('memberno') || h.includes('membercode'));
  const oName = findCol(oldHeaders, (h) => h.includes('membername'));
  const oCenter = findCol(oldHeaders, (h) => h.includes('center'));
  const nMap = new Map();
  newRows.forEach((r) => nMap.set(last4v(r[1]), { center: String(r[0] || ''), name: String(r[2] || '') }));
  const seen = new Set();
  const rows = oldRows.map((r) => {
    const key = last4v(oCode >= 0 ? r[oCode] : '');
    seen.add(key);
    const hit = nMap.get(key);
    if (!hit) return r;
    const copy = [...r];
    if (oName >= 0 && !String(copy[oName] || '').trim() && hit.name) copy[oName] = hit.name;
    if (oCenter >= 0 && !String(copy[oCenter] || '').trim() && hit.center) copy[oCenter] = hit.center;
    return copy;
  });
  let added = 0;
  newRows.forEach((r) => {
    const key = last4v(r[1]);
    if (seen.has(key)) return;
    seen.add(key); added += 1;
    const blank = oldHeaders.map(() => '');
    if (oCode >= 0) blank[oCode] = r[1];
    if (oName >= 0) blank[oName] = r[2];
    if (oCenter >= 0) blank[oCenter] = r[0];
    rows.push(blank);
  });
  return { headers: oldHeaders, rows, added };
}

/* তিনটি ডেটাবেজ আপডেট করে Neon-এ সেভ */
async function applyMisFiles() {
  const rules = window.COLLECTION_CSV;
  const status = $('#mis-upload-status');
  const btn = $('#btn-apply-mis-files');
  const done = [];
  btn.disabled = true;
  btn.textContent = '⏳ আপলোড হচ্ছে…';
  try {
    if (misSlots.installment) {
      const parsed = rules.parseInstallmentRows(misSlots.installment.rows);
      state.headers = parsed.headers;
      state.rows = parsed.rows;
      state.detect = detectColumns(parsed.headers);
      state.filters = { staff: '', center: '', member: '', searchBy: 'memberCode', date: '', followup: '', followupDate: '' };
      ['f-staff', 'f-center', 'f-member', 'f-search-key', 'f-date', 'f-followup', 'f-followup-date'].forEach((id) => { const el = $('#' + id); if (el) el.value = ''; });
      $('#f-search-key').value = 'memberCode';
      updateInstallmentSearchMode(false);
      done.push(`① কিস্তির তালিকা — ${fmt(parsed.rows.length)} সারি`);
    }
    if (misSlots.member) {
      const parsed = rules.parseMemberRows(misSlots.member.rows);
      /* সংগ্রহ-রিপোর্ট থেকে আসা তালিকায় মোবাইল/পিতার নাম থাকে না —
         তাই আগের সদস্য ডাটাবেজের তথ্য মুছে যায় না, শুধু মিলিয়ে বসে যায় */
      const thin = !parsed.headers.some((h) => /contact|mobile|father|husband|care/i.test(String(h)));
      if (thin && state.memberDB.length) {
        const merged = mergeThinMemberList(state.memberDB, state.memberDBHeaders, parsed.rows, parsed.headers);
        state.memberDBHeaders = merged.headers;
        state.memberDB = merged.rows;
        done.push(`② সদস্য তালিকা — ${fmt(merged.added)} জন নতুন · ${fmt(state.memberDB.length)} জন মোট`);
      } else {
        state.memberDBHeaders = parsed.headers;
        state.memberDB = parsed.rows;
        done.push(`② সদস্য তালিকা — ${fmt(parsed.rows.length)} জন`);
      }
    }
    if (misSlots.balance) {
      const parsed = rules.parseBalanceRows(misSlots.balance.rows);
      state.balanceHeaders = parsed.headers;
      state.balanceRows = parsed.rows;
      done.push(`③ পূর্বের স্থিতি — ${fmt(parsed.stats.members)} জন (${fmt(parsed.stats.records)} সারি থেকে)`);
    }
    if (!done.length) throw new Error('আপলোডের জন্য কোনো ফাইল নেই।');
    await persistRows();
    populateFilters();
    renderAll();
    renderToday();
    renderMemberDatabaseTable();
    status.innerHTML = `✅ আপলোড সম্পন্ন — ${done.join(' · ')}।<br>সব ডিভাইসে নতুন ডেটা পাওয়া যাবে।`;
    toast('✅ ফাইল আপলোড হয়েছে — সব ডেটাবেজ আপডেট');
  } catch (e) {
    status.innerHTML = `⚠️ ${esc(e.message)}`;
  } finally {
    btn.disabled = false;
    btn.textContent = '⬆️ ফাইলগুলো আপলোড করে ডেটাবেজ আপডেট করুন';
    renderMisSlots();
  }
}
function showPage(page) {
  state.activePage = page === 'today' ? 'today' : 'installments';
  $('#installment-page').classList.toggle('hidden', state.activePage !== 'installments');
  $('#today-page').classList.toggle('hidden', state.activePage !== 'today');
  $$('.page-tab').forEach((tab) => tab.classList.toggle('active', tab.dataset.page === state.activePage));
}

function updateModalScrollLock() {
  const open = $$('.modal-overlay').some((overlay) => !overlay.classList.contains('hidden'));
  document.body.classList.toggle('modal-open', open);
}

function openNativeDatePicker(input) {
  if (!input) return;
  if (typeof input.showPicker === 'function') {
    try { input.showPicker(); } catch { input.focus(); }
  } else {
    input.focus();
  }
}

function renderHeader() {
  $('#repo-badge').textContent = `⚠️ লগইন নেই · Neon · ${APP_VER} · বাংলা`;
  $('#sync-status').textContent = state.lastSync
    ? `সিঙ্ক হয়েছে ${state.lastSync.toLocaleTimeString('bn-BD')}`
    : 'সিঙ্ক হয়নি';
}

function renderAll() {
  renderHeader();
  renderTables();
  renderToday();
  renderHistory();
  showPage(state.activePage);
}

function populateFilters() {
  const d = state.detect;
  const fillSelect = (itemSel, selEl, idx, allLabel, labeler) => {
    const item = $(itemSel);
    if (idx < 0) { item.classList.add('hidden'); return; }
    item.classList.remove('hidden');
    const vals = sortAZ([...new Set(state.rows.map((r) => String(r[idx] ?? '').trim()).filter(Boolean))]);
    const cur = selEl.value;
    selEl.innerHTML = `<option value="">${allLabel}</option>` +
      vals.map((v) => `<option value="${esc(v)}">${esc(labeler ? labeler(v) : v)}</option>`).join('');
    if ([...selEl.options].some((o) => o.value === cur)) selEl.value = cur;
  };

  // ষ্টাফ ফিল্টার: নাম দিয়ে (না থাকলে কোড দিয়ে); সেন্টার তালিকা নির্বাচিত স্টাফ অনুযায়ী সীমিত।
  const staffIdx = d.staffName >= 0 ? d.staffName : d.staff;
  fillSelect('#fi-staff', $('#f-staff'), staffIdx, 'সব ষ্টাফ');
  const selectedStaff = $('#f-staff').value;
  const centerItem = $('#fi-center');
  const centerSelect = $('#f-center');
  if (d.centerCode < 0) {
    centerItem.classList.add('hidden');
    centerSelect.innerHTML = '<option value="">সব সেন্টার</option>';
  } else {
    centerItem.classList.remove('hidden');
    const eligibleRows = selectedStaff && staffIdx >= 0
      ? state.rows.filter((row) => norm(row[staffIdx]) === norm(selectedStaff))
      : state.rows;
    const centers = sortAZ([...new Set(eligibleRows.map((row) => String(row[d.centerCode] ?? '').trim()).filter(Boolean))]);
    const previousCenter = centerSelect.value;
    const shortLabels = new Map();
    centers.forEach((value) => {
      const short = displayCenterCode(value);
      shortLabels.set(value, (shortLabels.get(short) || 0) + 1);
    });
    centerSelect.innerHTML = '<option value="">সব সেন্টার</option>'
      + centers.map((value) => {
        const short = displayCenterCode(value);
        const label = shortLabels.get(short) > 1 ? value : short;
        return `<option value="${esc(value)}">${esc(label)}</option>`;
      }).join('');
    centerSelect.value = centers.some((value) => norm(value) === norm(previousCenter)) ? previousCenter : '';
  }
  state.filters.staff = $('#f-staff').value;
  state.filters.center = $('#f-center').value;
  $('#fi-member').classList.toggle('hidden', d.memberCode < 0 && d.memberName < 0);
  $('#fi-date').classList.toggle('hidden', d.date < 0);
}

/* ---------------- CSV আপলোড ফ্লো ---------------- */
function handleCSVFile(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const text = String(reader.result);
      const delim = detectDelimiter(text.split(/\r?\n/)[0] || '');
      const parsed = parseCSV(text, delim);
      if (parsed.length < 2) throw new Error('CSV-তে হেডার ও অন্তত ১ সারি দরকার।');
      const headers = parsed[0].map((h) => h.trim());
      const rows = parsed.slice(1).map((r) => headers.map((_, i) => (r[i] ?? '').toString().trim()));
      const detect = detectColumns(headers);
      state.csvData = { headers, rows, detect };

      $('#csv-detect').innerHTML = `<b>✅ অটো-শনানো কলাম:</b><br>` +
        DETECT_LABELS.map(([k, label]) => {
          const idx = detect[k];
          return idx >= 0
            ? `${label}: <b>${esc(headers[idx])}</b>`
            : `${label}: <span class="miss">পাওয়া যায়নি</span>`;
        }).join('<br>');

      $('#csv-preview-wrap').classList.remove('hidden');
      $('#csv-preview thead').innerHTML = `<tr>${headers.map((h) => `<th>${esc(h)}</th>`).join('')}</tr>`;
      $('#csv-preview tbody').innerHTML = rows.slice(0, 5)
        .map((r) => `<tr>${r.map((v, i) => `<td>${esc(i === detect.memberCode ? displayMemberCode(v) : v)}</td>`).join('')}</tr>`).join('');

      const errEl = $('#csv-error');
      if (detect.actual < 0) {
        errEl.textContent = '⚠️ CSV-তে "InstallmentActual" কলাম খুঁজে পাইনি। ফাইলটা ঠিক কিনা দেখুন — সমস্যা হলে ফাইলটা আমাকে পাঠান।';
        errEl.classList.remove('hidden');
        $('#btn-apply-csv').disabled = true;
      } else {
        if (detect.amount < 0) {
          errEl.textContent = '⚠️ "InstallmentAmount" কলাম পাইনি — সব আদায়কে সম্পূর্ণ আদায় ধরা হবে (আংশিক চিনতে পারবে না)।';
          errEl.classList.remove('hidden');
        } else {
          errEl.classList.add('hidden');
        }
        $('#btn-apply-csv').disabled = false;
      }
    } catch (e) {
      showCSVError(e.message);
      $('#btn-apply-csv').disabled = true;
      $('#csv-preview-wrap').classList.remove('hidden');
    }
  };
  reader.readAsText(file, 'UTF-8');
}

function showCSVError(msg) {
  const el = $('#csv-error');
  el.textContent = '⚠️ ' + msg;
  el.classList.remove('hidden');
}

async function applyCSV() {
  const { headers, rows, detect } = state.csvData;
  const btn = $('#btn-apply-csv');
  btn.disabled = true;
  btn.textContent = '⏳ তৈরি হচ্ছে...';

  state.headers = headers;
  state.rows = rows;
  state.detect = detect;
  state.filters = { staff: '', center: '', member: '', searchBy: 'memberCode', date: '', followup: '', followupDate: '' };
  $('#f-staff').value = ''; $('#f-center').value = ''; $('#f-member').value = ''; $('#f-search-key').value = 'memberCode'; $('#f-date').value = ''; $('#f-followup').value = ''; $('#f-followup-date').value = '';
  updateInstallmentSearchMode(false);

  populateFilters();
  renderAll();
  $('#csv-modal').classList.add('hidden');
  updateModalScrollLock();

  const c = countByStatus(rows);
  toast(`✅ ${fmt(rows.length)} সারি — বাকী ${fmt(c.due)} · আদায় ${fmt(c.paid)} · আংশিক ${fmt(c.partial)}`);

  btn.textContent = '📊 টেবিল দেখুন';
  btn.disabled = false;
  try {
    await persistRows();
  } catch (e) {
    toast('সেভ সমস্যা: ' + e.message, true);
  }
}

/* ---------------- Neon access setup ---------------- */
function showSetup() {
  $('#setup-screen').classList.remove('hidden');
  $('#app').classList.add('hidden');
  $('#set-refresh').value = settings.refreshSec;
  $('#set-autorefresh').checked = settings.autoRefresh;
}

function readSetupForm() {
  settings.mode = 'neon';
  settings.refreshSec = Math.max(10, Math.min(3600, num($('#set-refresh').value) || 60));
  settings.autoRefresh = $('#set-autorefresh').checked;
}

let syncTimer = null;
function restartSyncTimer() {
  clearInterval(syncTimer);
  if (settings.autoRefresh) {
    syncTimer = setInterval(async () => {
      try { await loadDB(true); } catch { /* নেটওয়ার্ক সমস্যা — চুপচাপ */ }
    }, settings.refreshSec * 1000);
  }
}

async function startApp() {
  $('#setup-screen').classList.add('hidden');
  $('#app').classList.remove('hidden');
  $('#sync-dot').className = 'dot';
  try {
    await loadDB();
  } catch (e) {
    $('#sync-status').textContent = 'সিঙ্ক এরর: ' + e.message;
    $('#sync-dot').classList.add('err');
    toast('ডাটা লোড করতে সমস্যা: ' + e.message, true);
    renderAll();
    return;
  }
  $('#sync-dot').classList.add('ok');
  populateFilters();
  collapseAllSections();
  renderAll();
  restartSyncTimer();
}

/* ---------------- Events ---------------- */
function bindEvents() {
  // হেডার বাটন
  $('#btn-refresh').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    btn.classList.add('spin');
    try { await loadDB(); $('#sync-dot').classList.add('ok'); populateFilters(); renderAll(); toast('🔄 রিফ্রেশ সম্পন্ন'); }
    catch (err) { toast('রিফ্রেশ ব্যর্থ: ' + err.message, true); }
    btn.classList.remove('spin');
  });
  const openUpload = () => {
    $('#csv-modal').classList.remove('hidden');
    updateModalScrollLock();
    $('#csv-preview-wrap').classList.add('hidden');
    $('#csv-error').classList.add('hidden');
    $('#btn-apply-csv').disabled = true;
    $('#csv-file').value = '';
  };
  $('#btn-upload')?.addEventListener('click', openUpload);  // হেডারের বাটন বাদ দেওয়া হয়েছে
  $('#btn-upload-2').addEventListener('click', openUpload);
  $('#btn-settings').addEventListener('click', showSetup);

  // পেজ ট্যাব
  $$('.page-tab').forEach((tab) => tab.addEventListener('click', () => showPage(tab.dataset.page)));
  $('#btn-add-today').addEventListener('click', addTodayRow);
  const cancelEditBtn = $('#btn-cancel-edit');
  if (cancelEditBtn) cancelEditBtn.addEventListener('click', () => cancelTodayEdit());
  // ↻ রিসেট = শুধু এন্ট্রি ঘরগুলো ফাঁকা করে; তালিকা, কিস্তি, খাতা — কিছুই বদলায় না
  $('#btn-reset-today').addEventListener('click', () => {
    clearTodayForm();
    toast('✅ এন্ট্রি ঘরগুলো ফাঁকা হয়েছে');
  });
  // ✔️ হিসাব ক্লোজ — আজকের সব এন্ট্রি তারিখভিত্তিক স্থায়ী খাতায় জমা হয় (কিস্তির অঙ্ক অপরিবর্তিত)
  $('#btn-close-today').addEventListener('click', closeTodayAccount);
  $('#history-date').addEventListener('change', renderHistory);
  $('#btn-clear-history-date').addEventListener('click', () => { $('#history-date').value=''; renderHistory(); });

  $('#btn-member-db').addEventListener('click', () => { $('#member-csv-status').textContent = state.memberDB.length ? `বর্তমানে ${fmt(state.memberDB.length)} সদস্য লোড আছে।` : 'এখনো সদস্য CSV আপলোড করা হয়নি।'; $('#member-csv-modal').classList.remove('hidden'); updateModalScrollLock(); });
  $('#btn-open-member-table').addEventListener('click', () => { renderMemberDatabaseTable(); $('#member-db-table-modal').classList.remove('hidden'); updateModalScrollLock(); });
  $('#member-db-code-search').addEventListener('input', renderMemberDatabaseTable);
  $('#member-db-center-search').addEventListener('input', renderMemberDatabaseTable);
  $('#member-db-list').addEventListener('click', (event) => { const row=event.target.closest('[data-member-db-index]'); if(row) openDirectoryMemberDetails(Number(row.dataset.memberDbIndex)); });
  $('#member-db-list').addEventListener('keydown', (event) => { if(event.key==='Enter'||event.key===' '){const row=event.target.closest('[data-member-db-index]');if(row){event.preventDefault();openDirectoryMemberDetails(Number(row.dataset.memberDbIndex));}} });
  $('#balance-csv-file').addEventListener('change', (e) => { if(e.target.files[0]) importBalanceCSV(e.target.files[0]); e.target.value=''; });
  $('#member-csv-file').addEventListener('change', (e) => { if(e.target.files[0]) importMemberCSV(e.target.files[0]); e.target.value=''; });
  // একসাথে তিনটি ফাইল আপলোড
  $('#btn-pick-mis-all')?.addEventListener('click', () => $('#mis-files-all')?.click());
  $('#mis-files-all')?.addEventListener('change', async (e) => {
    const files = Array.from(e.target.files || []);
    e.target.value = '';
    for (const file of files) await handleMisFile(file);
  });
  ['installment', 'member', 'balance'].forEach((slot) => {
    $('#btn-pick-mis-' + slot)?.addEventListener('click', () => $('#mis-file-' + slot)?.click());
    $('#mis-file-' + slot)?.addEventListener('change', async (e) => {
      const file = e.target.files && e.target.files[0];
      e.target.value = '';
      if (file) await handleMisFile(file);
    });
  });
  $('#btn-apply-mis-files')?.addEventListener('click', applyMisFiles);
  $('#today-member-code').addEventListener('input', fillTodayMember);
  $('#today-member-code').addEventListener('change', fillTodayMember);
  // লোন/সঞ্চয়/DPS টাইপ করলেই "এন্ট্রি পরে স্থিতি" লাইভ হিসাব হয় (সেভ ছাড়াই)।
  ['#today-loan', '#today-savings', '#today-dps'].forEach((sel) => {
    $(sel).addEventListener('input', () => { if (sel === '#today-loan') $(sel).dataset.autofill = '0'; renderTodayBalanceCard(); });
    $(sel).addEventListener('change', renderTodayBalanceCard);
  });
  $('#today-member-name').addEventListener('change', fillTodayMemberByName);
  ['#today-monthly-list', '#today-other-list'].forEach((sel) => {
    const body = $(sel); if (!body) return;
    body.addEventListener('click', (e) => {
      const editBtn = e.target.closest('[data-edit-today]');
      if (editBtn) { e.stopPropagation(); startEditToday(Number(editBtn.dataset.editToday)); return; }
      const delBtn = e.target.closest('[data-del-today]');
      if (delBtn) { e.stopPropagation(); deleteTodayRow(Number(delBtn.dataset.delToday)); return; }
      const row=e.target.closest('[data-today-index]'); if(row) openTodayDetails(Number(row.dataset.todayIndex));
    });
    body.addEventListener('keydown', (e) => { if(e.key==='Enter'||e.key===' '){ const row=e.target.closest('[data-today-index]'); if(row){e.preventDefault();openTodayDetails(Number(row.dataset.todayIndex));}} });
  });

  // ফিল্টার
  $('#f-staff').addEventListener('change', (e) => {
    state.filters.staff = e.target.value;
    populateFilters(); // কর্মী বদলালে শুধু ওই কর্মীর সেন্টারগুলো রাখে; অমিল পুরনো সেন্টার মুছে যায়
    renderTables();
  });
  $('#f-center').addEventListener('change', (e) => { state.filters.center = e.target.value; renderTables(); });
  $('#f-member').addEventListener('input', (e) => {
    const numericMode = ['memberCode', 'centerCode'].includes(state.filters.searchBy);
    if (numericMode) {
      const english = toEn(e.target.value);
      if (english !== e.target.value) e.target.value = english;
    }
    state.filters.member = e.target.value.trim();
    renderTables();
  });
  $('#f-member').addEventListener('change', (e) => { state.filters.member = e.target.value.trim(); renderTables(); });
  $('#f-search-key').addEventListener('change', () => { updateInstallmentSearchMode(); renderTables(); });
  $('#section-view-filter').addEventListener('change', (e) => { state.sectionView = e.target.value; applySectionView(); });
  $('#f-date').addEventListener('change', (e) => { state.filters.date = e.target.value; renderTables(); });
  $('#f-followup').addEventListener('input', (e) => { state.filters.followup = e.target.value.trim(); renderTables(); });
  $('#f-followup-date').addEventListener('change', (e) => { state.filters.followupDate = e.target.value; renderTables(); });
  $('#btn-clear-filters').addEventListener('click', () => {
    state.filters = { staff: '', center: '', member: '', searchBy: 'memberCode', date: '', followup: '', followupDate: '' };
    $('#f-staff').value = ''; $('#f-center').value = ''; $('#f-member').value = ''; $('#f-search-key').value = 'memberCode'; $('#f-date').value = ''; $('#f-followup').value = ''; $('#f-followup-date').value = '';
    updateInstallmentSearchMode(false);
    populateFilters();
    renderTables();
    toast('✖ ফিল্টার মুছে ফেলা হয়েছে');
  });

  // চিপস → সেকশনে স্ক্রল
  [['chip-due', 'sec-due'], ['chip-paid', 'sec-paid'], ['chip-partial', 'sec-partial']].forEach(([chip, sec]) => {
    $('#' + chip).addEventListener('click', () => {
      const el = $('#' + sec);
      expandSection(sec);
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });

  // কোল্যাপস
  $$('.table-head').forEach((h) => h.addEventListener('click', () => {
    $('#' + h.dataset.collapse).classList.toggle('collapsed');
  }));

  // মডাল বন্ধ
  const closeModal = (overlay) => {
    if (overlay) overlay.classList.add('hidden');
    updateModalScrollLock();
  };
  $$('[data-close]').forEach((button) => button.addEventListener('click', () => closeModal($('#' + button.dataset.close))));
  $$('.modal-overlay').forEach((overlay) => overlay.addEventListener('click', (event) => {
    if (event.target === overlay) closeModal(overlay);
  }));
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      const openOverlay = $$('.modal-overlay').find((overlay) => !overlay.classList.contains('hidden'));
      if (openOverlay) closeModal(openOverlay);
    }
  });

  // CSV
  $('#csv-file').addEventListener('change', (e) => { if (e.target.files[0]) handleCSVFile(e.target.files[0]); });
  $('#drop-zone').addEventListener('click', () => $('#csv-file').click());
  $('#drop-zone').addEventListener('dragover', (e) => { e.preventDefault(); $('#drop-zone').classList.add('dragover'); });
  $('#drop-zone').addEventListener('dragleave', () => $('#drop-zone').classList.remove('dragover'));
  $('#drop-zone').addEventListener('drop', (e) => {
    e.preventDefault();
    $('#drop-zone').classList.remove('dragover');
    const f = e.dataTransfer.files[0];
    if (f) handleCSVFile(f);
  });
  $('#btn-apply-csv').addEventListener('click', applyCSV);

  // সারি ক্লিক → সদস্যের তথ্য; 📝 → প্রতিশ্রুতি মডাল
  ['#tbl-today-promise', '#tbl-payable', '#tbl-due', '#tbl-paid', '#tbl-partial'].forEach((selector) => {
    if (!$(selector)) return;
    $(selector).addEventListener('click', (event) => {
      const followupButton = event.target.closest('[data-followup-index]');
      if (followupButton) {
        event.preventDefault();
        event.stopPropagation();
        openFollowupModal(Number(followupButton.dataset.followupIndex));
        return;
      }
      const row = event.target.closest('[data-row-index]');
      if (row) openMemberDetailsFromRow(Number(row.dataset.rowIndex));
    });
  });
  $('#btn-save-followup').addEventListener('click', saveFollowup);
  ['#f-date', '#f-followup-date', '#followup-date', '#history-date'].forEach((selector) => {
    const input = $(selector);
    input.addEventListener('click', () => openNativeDatePicker(input));
    input.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') openNativeDatePicker(input);
    });
    const wrapper = input.closest('.filter-item, .date-field, .date-input-field');
    if (wrapper) wrapper.addEventListener('click', (event) => {
      if (event.target === input) return;
      if (event.target.closest('label')) event.preventDefault();
      openNativeDatePicker(input);
    });
  });

  // Public Neon API connection check and UI settings
  $('#btn-test-conn').addEventListener('click', async () => {
    const errEl = $('#setup-error');
    errEl.classList.add('hidden');
    try {
      const document = await neonRead();
      toast(`✅ Neon সংযোগ সফল — ${fmt((document.rows || []).length)} সারি`);
    } catch (e) {
      errEl.textContent = '⚠️ ' + e.message;
      errEl.classList.remove('hidden');
    }
  });
  $('#btn-save-settings').addEventListener('click', () => {
    readSetupForm();
    saveSettings();
    $('#setup-screen').classList.add('hidden');
    startApp();
    toast('💾 সেটিংস সেভ হয়েছে');
  });
}

/* ---------------- Init ---------------- */
bindEvents();
if (window.visualViewport) {
  const syncVisualViewport = () => document.documentElement.style.setProperty('--visual-vh', `${window.visualViewport.height}px`);
  window.visualViewport.addEventListener('resize', syncVisualViewport);
  syncVisualViewport();
}
const appHeader = $('.app-header');
const syncStickyPageTabs = () => {
  const height = appHeader?.getBoundingClientRect().height || 88;
  document.documentElement.style.setProperty('--app-header-height', `${height}px`);
};
if (appHeader && 'ResizeObserver' in window) new window.ResizeObserver(syncStickyPageTabs).observe(appHeader);
window.addEventListener('resize', syncStickyPageTabs);
requestAnimationFrame(syncStickyPageTabs);
startApp();
