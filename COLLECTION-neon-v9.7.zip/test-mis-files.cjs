/* যাচাই: তিনটি MIS ফাইল একসাথে আপলোড করে তিনটি ডেটাবেজ আপডেট
   ① কিস্তির তালিকা — gBanker এক্সপোর্ট (HTML, .xls নামে সেভ করা)
   ② সদস্য তালিকা   — gBanker এক্সপোর্ট (লেগ্য .xls)
   ③ পূর্বের স্থিতি  — "Balance Compare with Passbook (POMIS)" (CSV)
   ফাইলগুলোর ধরন অ্যাপ নিজে থেকেই শনাক্ত করে ঠিক ডেটাবেজে বসাতে হবে। */
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const { JSDOM } = require('jsdom');

const ROOT = __dirname;
const FIX = path.join(ROOT, 'test-fixtures');
const UPLOADS = '/home/user/uploads';

const w = new JSDOM(fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8'), {
  url: 'https://demo.invalid', runScripts: 'outside-only', pretendToBeVisual: true,
}).window;
w.HTMLElement.prototype.scrollIntoView = () => {};
w.confirm = () => true;
w.scrollTo = () => {};
w.fetch = (url, opts) => {
  if (opts && opts.method === 'PUT') return Promise.resolve({ ok: true, status: 200, json: async () => ({ ok: true }) });
  return new Promise(() => {});
};
w.eval(fs.readFileSync(path.join(ROOT, 'shared/csv-rules.js'), 'utf8'));
w.eval(fs.readFileSync(path.join(ROOT, 'shared/xls-reader.js'), 'utf8'));
w.eval(fs.readFileSync(path.join(ROOT, 'app.js'), 'utf8') + `
;window.__state = state;
window.__handleMisFile = handleMisFile;
window.__applyMisFiles = applyMisFiles;
window.__misSlots = misSlots;
window.__parseReportFile = parseReportFile;
`);

const state = w.__state;
const $ = (sel) => w.document.querySelector(sel);
const results = [];
const check = (name, fn) => {
  try { fn(); results.push(`✅ ${name}`); }
  catch (e) { results.push(`❌ ${name} → ${e.message}`); process.exitCode = 1; }
};

const makeFile = (bytes, name, type) => new w.File([bytes], name, { type: type || 'application/octet-stream' });
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  /* ---------- ১) ফাইল শনাক্ত (ফরম্যাট অনুযায়ী) ---------- */
  const instFile = path.join(FIX, 'installment-sample.html');
  const memberFile = path.join(FIX, 'members-sample.xls');
  const passbookFile = path.join(UPLOADS, 'Loan_SavingsBalanceDeclineCenter20_Oct_2026_105531+06_00.csv');

  check('HTML এক্সপোর্ট ফাইল → কিস্তির তালিকা', async () => {});
  const instParsed = await w.__parseReportFile(makeFile(fs.readFileSync(instFile), 'installment.xls'));
  check('HTML ফাইলকে "কিস্তির তালিকা" চেনা হয়েছে', () => {
    assert.strictEqual(instParsed.format, 'html');
    assert.strictEqual(instParsed.type, 'installment');
    assert.ok(instParsed.rows.length > 1);
  });

  const memParsed = await w.__parseReportFile(makeFile(fs.readFileSync(memberFile), 'MemberlistReport.xls'));
  check('লেগ্য .xls ফাইল → সদস্য তালিকা', () => {
    assert.strictEqual(memParsed.format, 'xls');
    assert.strictEqual(memParsed.type, 'member');
  });

  let passbookParsed = null;
  if (fs.existsSync(passbookFile)) {
    passbookParsed = await w.__parseReportFile(makeFile(fs.readFileSync(passbookFile), 'Loan_SavingsBalance.csv'));
    check('পাসবুক CSV ফাইল → পূর্বের স্থিতি', () => {
      assert.strictEqual(passbookParsed.format, 'csv');
      assert.strictEqual(passbookParsed.type, 'balance');
    });
  } else {
    results.push('⚠️ পাসবুক CSV ফাইল নেই — ওই অংশটি বাদ');
  }

  /* ---------- ২) একসাথে আপলোড → তিনটি ডেটাবেজ ---------- */
  state.rows = []; state.headers = [];
  state.memberDB = []; state.memberDBHeaders = [];
  state.balanceRows = []; state.balanceHeaders = [];

  await w.__handleMisFile(makeFile(fs.readFileSync(instFile), 'installment.xls'));
  await w.__handleMisFile(makeFile(fs.readFileSync(memberFile), 'MemberlistReport.xls'));
  if (passbookParsed) await w.__handleMisFile(makeFile(fs.readFileSync(passbookFile), 'Loan_SavingsBalance.csv'));

  check('তিনটি ফাইল তিনটি ঘরে বসেছে', () => {
    const slots = w.__misSlots;
    assert.ok(slots.installment, 'কিস্তির ফাইল বসেনি');
    assert.ok(slots.member, 'সদস্যের ফাইল বসেনি');
    if (passbookParsed) assert.ok(slots.balance, 'স্থিতির ফাইল বসেনি');
  });
  check('প্রতিটি ঘরে ফাইলের নাম ও ধরন দেখাচ্ছে', () => {
    assert.ok($('#mis-status-installment').textContent.includes('installment.xls'), $('#mis-status-installment').textContent);
    assert.ok($('#mis-status-member').textContent.includes('MemberlistReport.xls'), $('#mis-status-member').textContent);
  });
  check('আপলোড বাটন চালু হয়েছে', () => assert.strictEqual($('#btn-apply-mis-files').disabled, false));

  await w.__applyMisFiles();
  await wait(200);

  check('কিস্তির তালিকা ডেটাবেজ আপডেট হয়েছে', () => {
    assert.ok(state.rows.length > 1, 'কিস্তির সারি নেই');
    assert.ok(state.headers.includes('MemberCode'), 'হেডার নেই');
  });
  check('সদস্য ডেটাবেজ আপডেট হয়েছে (৪০০ জন)', () => {
    assert.strictEqual(state.memberDB.length, 400);
    assert.ok(state.memberDBHeaders.join(' ').includes('Member'));
  });
  if (passbookParsed) {
    check('পূর্বের স্থিতি ডেটাবেজ আপডেট হয়েছে (৯১৩ জন)', () => {
      assert.strictEqual(state.balanceRows.length, 913);
      assert.strictEqual(state.balanceHeaders[0], 'Member ID');
    });
    check('স্থিতির সংখ্যা ঠিক (পাসবুক রিপোর্টের সাথে মিলেছে)', () => {
      const row = state.balanceRows.find((r) => String(r[2]) === 'Bipul');
      assert.ok(row, 'Bipul পাওয়া যায়নি');
      assert.strictEqual(Number(row[3]), 6);      // সঞ্চয়
      assert.strictEqual(Number(row[4]), 0);      // DPS
      assert.strictEqual(Number(row[5]), 7178);   // লোন
    });
    check('স্থিতির সেন্টার (সামিতি) ধরা পড়েছে', () => {
      assert.strictEqual(String(state.balanceRows[0][6]), '0003');
    });
  }
  check('স্ট্যাটাস মেসেজ দেখাচ্ছে', () => {
    const txt = $('#mis-upload-status').textContent;
    assert.ok(txt.includes('আপলোড সম্পন্ন'), txt);
  });

  console.log('\n' + results.join('\n'));
  const failed = results.filter((r) => r.startsWith('❌')).length;
  console.log(`\n✅ পাস: ${results.length - failed}   ❌ ফেল: ${failed}`);
  process.exit(failed ? 1 : 0);
})().catch((error) => {
  console.error('TEST CRASH:', error);
  process.exit(1);
});
