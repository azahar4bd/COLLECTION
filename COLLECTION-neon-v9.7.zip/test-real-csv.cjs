/* রাউন্ড-৯ যাচাই: আসল আপলোড করা ফাইল দিয়ে দুটি ডেটাবেজ আপডেট
   ① MemberlistReport (2).csv → সদস্য ডেটাবেজ
   ② Balance.csv (নতুন MIS ফরম্যাট) → পূর্বের স্থিতি ডেটাবেজ
   ③ MonthlySavings…csv (পুরোনো Samity ফরম্যাট) → আগের মতো আলাদা সারি */
const fs = require('fs');
const { JSDOM } = require('jsdom');

const w = new JSDOM(fs.readFileSync('index.html', 'utf8'), {
  url: 'https://demo.invalid', runScripts: 'outside-only', pretendToBeVisual: true,
}).window;
w.HTMLElement.prototype.scrollIntoView = () => {};
w.confirm = () => true;
w.scrollTo = () => {};
// GET (load) কখনো শেষ হবে না → টেস্টের ডেটা মুছবে না; PUT (save) সফল।
w.fetch = (url, opts) => {
  if (opts && opts.method === 'PUT') return Promise.resolve({ ok: true, status: 200, json: async () => ({ ok: true }) });
  return new Promise(() => {});
};
w.eval(fs.readFileSync('shared/csv-rules.js', 'utf8'));
w.eval(fs.readFileSync('app.js', 'utf8') + `
;window.__state = state;
window.__importMemberCSV = importMemberCSV;
window.__importBalanceCSV = importBalanceCSV;
`);

const state = w.__state;
let pass = 0, fail = 0;
const ok = (cond, msg, extra) => {
  if (cond) { pass++; console.log('  ✅ ' + msg); }
  else { fail++; console.log('  ❌ ' + msg + (extra !== undefined ? ' → ' + JSON.stringify(extra) : '')); }
};
const num = (v) => {
  const s = String(v === undefined || v === null ? '' : v).replace(/[,\s]/g, '').replace(/[^\d.\-]/g, '');
  const n = parseFloat(s);
  return isNaN(n) ? 0 : n;
};
const $ = (sel) => w.document.querySelector(sel);
const nh = (s) => String(s === undefined || s === null ? '' : s).toLowerCase().replace(/[^a-z0-9]/g, '');

function makeFile(text, name) {
  return new w.File([text], name || 'x.csv', { type: 'text/csv' });
}
function importAndWait(fn, file, statusSel) {
  return new Promise((resolve) => {
    const t0 = Date.now();
    fn(file);
    const iv = setInterval(() => {
      const txt = $(statusSel).textContent.trim();
      if (txt) { clearInterval(iv); resolve(txt); }
      else if (Date.now() - t0 > 20000) { clearInterval(iv); resolve(''); }
    }, 25);
  });
}

const memberFile = '/home/user/uploads/MemberlistReport (2).csv';
const balanceFile = '/home/user/uploads/Balance.csv';
const oldBalanceFile = '/home/user/uploads/MonthlySavings_And_LoanReport18_Oct_2026_095837+06_00.csv';

(async () => {
  console.log('\n=== ① সদস্যের তথ্যের CSV (MemberlistReport) ===');
  if (fs.existsSync(memberFile)) {
    const text = fs.readFileSync(memberFile, 'utf8');
    state.memberDB = []; state.memberDBHeaders = [];
    const msg = await importAndWait(w.__importMemberCSV, makeFile(text, 'MemberlistReport (2).csv'), '#member-csv-status');
    ok(state.memberDB.length === 5081, 'সদস্য ৫,০৮১ জন ইমপর্ট হয়েছে', state.memberDB.length);
    const st = state.memberDBHeaders.findIndex(h => nh(h).includes('status'));
    const stCount = {};
    state.memberDB.forEach(r => { const s = String(r[st] || '').trim(); stCount[s] = (stCount[s] || 0) + 1; });
    ok(stCount['Active'] === 738 && stCount['Drop'] === 4337 && stCount['Rejected'] === 6,
      'স্ট্যাটাস: Active 738 / Drop 4337 / Rejected 6', stCount);
    ok(msg.includes('৫,০৮১'), 'মেসেজে সদস্য সংখ্যা দেখাচ্ছে', msg.slice(0, 90));
    ok(msg.includes('Active') && msg.includes('Drop'), 'স্ট্যাটাস ব্রেকডাউন দেখাচ্ছে', msg.slice(0, 140));
    const gd = state.memberDBHeaders.findIndex(h => nh(h).includes('father') || nh(h).includes('husband') || nh(h).includes('care'));
    const withG = state.memberDB.filter(r => String(r[gd] || '').trim()).length;
    ok(withG === 4933, 'অভিভাবক ৪,৯৩৩ জনের আছে', withG);
  } else { console.log('  ⚠️ member file নেই'); fail++; }

  console.log('\n=== ② পূর্বের স্থিতির CSV (Balance.csv — নতুন MIS ফরম্যাট) ===');
  if (fs.existsSync(balanceFile)) {
    const text = fs.readFileSync(balanceFile, 'utf8');
    state.balanceRows = []; state.balanceHeaders = [];
    const msg = await importAndWait(w.__importBalanceCSV, makeFile(text, 'Balance.csv'), '#balance-csv-status');
    ok(!msg.startsWith('⚠️'), 'ইমপর্ট ব্যর্থ হয়নি', msg.slice(0, 180));
    ok(state.balanceRows.length === 913, '৯১৩ জন সদস্যের সারি তৈরি হয়েছে', state.balanceRows.length);
    ok(msg.includes('৯১৩'), 'মেসেজে সদস্য সংখ্যা দেখাচ্ছে', msg.slice(0, 140));
    ok(/DPS/.test(msg), 'DPS না থাকার নোট দেখাচ্ছে', msg.slice(0, 220));

    const H = state.balanceHeaders;
    const idIdx = H.findIndex(h => nh(h).includes('memberid'));
    const nameIdx = H.findIndex(h => nh(h).includes('membername'));
    const savIdx = H.findIndex(h => nh(h).includes('savings'));
    const loanIdx = H.findIndex(h => nh(h).includes('loan'));
    ok(idIdx === 0 && nameIdx === 2 && savIdx === 3 && loanIdx === 5,
      'কলাম ইন্ডেক্স ঠিক (id0/name2/savings3/loan5)', { idIdx, nameIdx, savIdx, loanIdx });
    ok(state.balanceRows.every(r => r.length === H.length + 1),
      'প্রতিটি সারিতে সেন্টার কলাম যুক্ত (headers.length+1)', state.balanceRows[0].length);

    // কাঁচা ফাইল থেকে প্রতি সদস্যের প্রোডাক্ট-ভিত্তিক সারি
    const lines = text.split(/\r?\n/).filter(l => l.trim());
    const csvLines = lines.filter(l => !/^Item Code/i.test(l.trim()) && !/^Member ID/i.test(l.trim()));
    const perMember = new Map();
    csvLines.forEach(l => {
      const cells = l.split(',');
      const id = String(cells[0] || '').replace(/^0+/, '');
      if (!/^\d+$/.test(id)) return;
      perMember.set(id, (perMember.get(id) || 0) + 1);
    });
    const multi = [...perMember.entries()].filter(([, n]) => n > 1);
    ok(multi.length === 43, '৪৩ জন সদস্যের ২টি করে প্রোডাক্ট সারি আছে', multi.length);

    let sampleOk = true, sample = null;
    for (const [id] of multi.slice(0, 8)) {
      const row = state.balanceRows.find(r => String(r[idIdx]) === id);
      if (!row) { sampleOk = false; sample = { id, why: 'row missing' }; break; }
      let sSum = 0, lSum = 0;
      csvLines.forEach(l => {
        const cells = l.split(',');
        if (String(cells[0] || '').replace(/^0+/, '') === id) { sSum += num(cells[3]); lSum += num(cells[5]); }
      });
      if (num(row[savIdx]) !== sSum || num(row[loanIdx]) !== lSum) {
        sampleOk = false; sample = { id, gotSav: num(row[savIdx]), sSum, gotLoan: num(row[loanIdx]), lSum }; break;
      }
    }
    ok(sampleOk, 'একাধিক প্রোডাক্টের সদস্যের সঞ্চয়/লোন যোগ করে বসানো হয়েছে', sample);

    // সব সারির সদস্য মেম্বার ডিবিতে আছে কি না
    const memCodeIdx = state.memberDBHeaders.findIndex(h => nh(h).includes('memberno'));
    const memCodes = new Set(state.memberDB.map(r => String(r[memCodeIdx] || '').replace(/^0+/, '')).filter(Boolean));
    let unmatched = 0;
    state.balanceRows.forEach(r => {
      const id = String(r[idIdx] || '');
      if (memCodes.has(id)) return;
      if ([...memCodes].some(c => c.endsWith(id) || id.endsWith(c))) return;
      unmatched++;
    });
    ok(unmatched === 0, 'সব স্থিতির সদস্য মেম্বার ডিবিতে মেলেছে', unmatched);
  } else { console.log('  ⚠️ balance file নেই'); fail++; }

  console.log('\n=== ③ পুরোনো ফরম্যাট (Samity) — প্রতিটি সারি আলাদা ===');
  if (fs.existsSync(oldBalanceFile)) {
    const text = fs.readFileSync(oldBalanceFile, 'utf8');
    state.balanceRows = []; state.balanceHeaders = [];
    const msg = await importAndWait(w.__importBalanceCSV, makeFile(text, 'old.csv'), '#balance-csv-status');
    ok(!msg.startsWith('⚠️'), 'পুরোনো ফরম্যাট ইমপর্ট হয়েছে', msg.slice(0, 180));
    ok(state.balanceRows.length === 5592, '৫,৫৯২ সারি আলাদা আলাদা রয়েছে', state.balanceRows.length);
    const H2 = state.balanceHeaders;
    const centers = new Set(state.balanceRows.map(r => String(r[H2.length] || '').trim()).filter(Boolean));
    ok(centers.size >= 70, 'সেন্টার/সামিটি কলাম পূর্ণ', centers.size);
    const id2 = H2.findIndex(h => nh(h).includes('memberid'));
    const byId = new Map();
    state.balanceRows.forEach(r => { const id = String(r[id2] || ''); byId.set(id, (byId.get(id) || 0) + 1); });
    const rep = [...byId.values()].filter(n => n > 1).length;
    ok(rep > 500, 'একই ID বারবার (সামিটিভিত্তে) রয়েছে — যোগ করা হয়নি', rep);
  } else { console.log('  ⚠️ old balance file নেই'); fail++; }


  console.log('\n=== ④ এন্ড-টু-এন্ড: টাইপ করলে কার্ডে ঠিক স্থিতি দেখা যায় ===');
  if (fs.existsSync(balanceFile) && fs.existsSync(memberFile)) {
    // নতুন ফরম্যাটের ফাইল আবার ইমপর্ট করি (পুরোনো ফরম্যাটের পরে state বদলে গেছে)
    state.balanceRows = []; state.balanceHeaders = [];
    await importAndWait(w.__importBalanceCSV, makeFile(fs.readFileSync(balanceFile, 'utf8'), 'Balance.csv'), '#balance-csv-status');
    // নমুনা সদস্য বেছে নাও
    const H3 = state.balanceHeaders;
    const id3 = H3.findIndex(h => nh(h).includes('memberid'));
    const sav3 = H3.findIndex(h => nh(h).includes('savings'));
    const dps3 = H3.findIndex(h => nh(h).includes('dps'));
    const loan3 = H3.findIndex(h => nh(h).includes('loan'));
    const memCode3 = state.memberDBHeaders.findIndex(h => nh(h).includes('memberno'));
    const memName3 = state.memberDBHeaders.findIndex(h => nh(h).includes('membername'));
    const step = Math.floor(state.balanceRows.length / 25);
    const bnToNum = (t) => {
      const map = { '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4', '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9' };
      return Number(String(t).replace(/[০-৯]/g, d => map[d]).replace(/[^0-9.]/g, '')) || 0;
    };
    const chipVal = (kind) => {
      const el = [...$('#today-balance-summary').querySelectorAll('.balance-chip.' + kind)][0];
      return el ? bnToNum(el.textContent) : null;
    };
    let good = 0, bad = null, checked = 0;
    for (let i = 0; i < state.balanceRows.length; i += step) {
      const row = state.balanceRows[i];
      const bid = String(row[id3]);
      const mem = state.memberDB.find(r => String(r[memCode3]).replace(/^0+/, '') === bid || String(r[memCode3]).replace(/^0+/, '').endsWith(bid));
      if (!mem) continue;
      const disp = String(mem[memCode3]).replace(/^0+/, '').slice(-4);
      const input = $('#today-member-code');
      input.value = disp;
      input.dispatchEvent(new w.Event('input', { bubbles: true }));
      const expLoan = num(row[loan3]), expSav = num(row[sav3]), expDps = num(row[dps3]);
      const gotLoan = chipVal('loan'), gotSav = chipVal('savings'), gotDps = chipVal('dps');
      checked++;
      if (gotLoan === expLoan && gotSav === expSav && gotDps === expDps) good++;
      else if (!bad) bad = { bid, disp, expLoan, gotLoan, expSav, gotSav, expDps, gotDps };
    }
    ok(checked >= 20, 'নমুনা সদস্য যাচাই হয়েছে', checked);
    ok(bad === null, 'কার্ডে লোন/সঞ্চয়/DPS ঠিকমতো দেখাচ্ছে', bad);
    console.log(`     (যাচাই করা সদস্য: ${checked}, সঠিক: ${good})`);
  }

  console.log('\n=== ফলাফল ===');
  console.log(`  ✅ পাস: ${pass}   ❌ ফেল: ${fail}`);
  process.exit(fail ? 1 : 0);
})();
